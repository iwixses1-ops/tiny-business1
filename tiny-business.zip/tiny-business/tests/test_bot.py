# -*- coding: utf-8 -*-
"""
Интеграционные тесты ботовой логики (без реальной сети Telegram).

Мы вызываем обработчики aiogram напрямую с фиктивными CallbackQuery/Message
объектами, подменяя методы ответа. Вся игровая логика при этом настоящая
(backend.game).
"""

from __future__ import annotations

import asyncio

import pytest

import bot.main as bot
from backend import game as g


class FakeUser:
    def __init__(self, user_id, first_name="Игрок", last_name="", username=None):
        self.id = user_id
        self.first_name = first_name
        self.last_name = last_name
        self.username = username


class FakeMessage:
    def __init__(self, user_id, text="", args=""):
        self.from_user = FakeUser(user_id)
        self.text = text
        self._args = args
        self.sent = []
        self.edited = []

    def get_args(self):
        return self._args

    async def answer(self, text, **kwargs):
        self.sent.append(text)
        return None

    async def edit_text(self, text, **kwargs):
        self.edited.append(text)
        return None


class FakeCallback:
    def __init__(self, user_id, data, message: FakeMessage):
        self.from_user = FakeUser(user_id)
        self.data = data
        self.message = message
        self.toasts = []

    async def answer(self, text="", show_alert=False):
        self.toasts.append((text, show_alert))
        return None


def run(coro):
    """Запускает корутину в свежем event loop (надёжно для 3.10+)."""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.close()


@pytest.fixture(autouse=True)
def _patch_db(monkeypatch, db):
    """Заставляет bot.main использовать тестовую БД вместо глобального синглтона."""
    monkeypatch.setattr(bot, "get_db", lambda: db)


def test_start_creates_player_and_shows_menu(db):
    msg = FakeMessage(1)
    run(bot.cmd_start(msg))
    assert msg.sent, "должно быть отправлено сообщение"
    assert "Tiny Business" in msg.sent[0]
    # Игрок создан
    me = g.get_me(db, 1, "Игрок")
    assert me["balance"] == 100


def test_buy_business_from_callback(db):
    # Даём денег
    uid = 2
    g.ensure_player(db, uid, "Игрок")
    g.grant_balance(db, uid, 500)

    msg = FakeMessage(uid)
    cb = FakeCallback(uid, "buy_biz:grocery_store", msg)
    run(bot.cb_buy_business(cb))

    assert cb.toasts, "должен быть результат"
    assert cb.toasts[0][1] is False  # успех
    me = g.get_me(db, uid, "Игрок")
    biz = {b["business_id"]: b for b in me["businesses"]}
    assert biz["grocery_store"]["owned"] is True


def test_buy_business_insufficient_shows_alert(db):
    uid = 3
    g.ensure_player(db, uid, "Игрок")  # баланс 100
    msg = FakeMessage(uid)
    cb = FakeCallback(uid, "buy_biz:pizzeria", msg)  # стоит 5000
    run(bot.cb_buy_business(cb))
    assert cb.toasts
    assert cb.toasts[0][1] is True  # alert об ошибке


def test_profile_contains_referral_link(db):
    uid = 4
    g.ensure_player(db, uid, "Игрок")
    msg = FakeMessage(uid)
    cb = FakeCallback(uid, "profile", msg)
    run(bot.cb_profile(cb))
    texts = msg.sent + msg.edited
    assert texts, "должен быть ответ"
    text = texts[0]
    assert "Пригласи друга" in text
    assert "ref_" in text


def test_tasks_flow_claim_once(db):
    uid = 5
    g.ensure_player(db, uid, "Игрок")
    # Открываем бизнес → задание open_business станет выполнено
    g.grant_balance(db, uid, 5000)
    g.buy_business(db, uid, "grocery_store")

    msg = FakeMessage(uid)
    cb = FakeCallback(uid, "tasks", msg)
    run(bot.cb_tasks(cb))
    texts = msg.sent + msg.edited
    assert texts, "должен быть ответ"
    text = texts[0]
    assert "Задания" in text

    # Находим ключ выполненного задания и забираем его (если есть).
    tasks = g.get_tasks(db, uid)
    done = [t for t in tasks if t["done"] and not t["claimed"]]
    assert done, "после аттрибуций должно быть выполненное задание"
    key = done[0]["key"]
    cb2 = FakeCallback(uid, f"claim_task:{key}", msg)
    run(bot.cb_claim_task(cb2))
    # Повторная попытка — нельзя получить награду дважды
    cb3 = FakeCallback(uid, f"claim_task:{key}", msg)
    run(bot.cb_claim_task(cb3))
    assert cb3.toasts, "должен быть ответ"
    # последний тост — от claim (это может быть после перерисовки задач,
    # поэтому ищем первый тост с show_alert=True в cb3)
    assert any(sa for _, sa in cb3.toasts), "повторное получение должно показать alert"


def test_referral_flow_via_bot(db):
    """inviter приглашает invitee через deep link; награда 1 раз."""
    inviter = 10
    invitee = 11
    g.ensure_player(db, inviter, "Инв")
    bal_before = g.get_me(db, inviter, "Инв")["balance"]

    # invitee жмёт ссылку ref_10
    msg = FakeMessage(invitee, args="ref_10")
    run(bot.cmd_start(msg))

    # Инв получает награду
    bal_after = g.get_me(db, inviter, "Инв")["balance"]
    assert bal_after > bal_before
    assert bal_after - bal_before == bot_ref_reward()


def bot_ref_reward():
    import backend.game as gg
    return gg.REFERRAL_REWARD


def _flatten_kb(kb):
    return [btn for row in kb.inline_keyboard for btn in row]


def test_home_kb_has_webapp_button_when_https(monkeypatch):
    """При HTTPS-адресе Mini App в меню появляется кнопка «Играть»."""
    monkeypatch.setattr(bot.config, "WEBAPP_URL", "https://bot1234.bothost.tech")
    kb = bot._home_kb()
    web = [b for b in _flatten_kb(kb) if b.web_app is not None]
    assert len(web) == 1
    assert web[0].web_app.url == "https://bot1234.bothost.tech"


def test_home_kb_no_webapp_button_when_http(monkeypatch):
    """При http:// кнопки Mini App нет (Telegram её не примет)."""
    monkeypatch.setattr(bot.config, "WEBAPP_URL", "http://127.0.0.1:8080")
    kb = bot._home_kb()
    web = [b for b in _flatten_kb(kb) if b.web_app is not None]
    assert len(web) == 0