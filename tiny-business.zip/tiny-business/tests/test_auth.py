# -*- coding: utf-8 -*-
"""
Тесты аутентификации: проверка подписи Telegram, локальный тестовый режим,
отказ при невалидных/устаревших данных.
"""

from __future__ import annotations

import time

import pytest

from backend import auth
import backend.config as cfg


@pytest.fixture(autouse=True)
def _reset_config(monkeypatch):
    """Гарантируем детерминированную конфигурацию для тестов."""
    monkeypatch.setattr(cfg.config, "ALLOW_LOCAL_TEST", False)
    monkeypatch.setattr(cfg.config, "BOT_TOKEN", "TEST:token-for-tests")
    monkeypatch.setattr(cfg.config, "AUTH_MAX_AGE_SECONDS", 600)
    yield


def test_valid_signature_passes():
    """Правильно подписанные данные проходят проверку."""
    init_data = auth.make_test_init_data(12345)
    result = auth.validate_init_data(init_data)
    assert result is not None
    assert result[0] == 12345


def test_tampered_data_fails():
    """Изменённые данные не проходят (подпись не совпадает)."""
    init_data = auth.make_test_init_data(12345)
    # испортим что-то внутри подписи
    tampered = init_data.replace("12345", "99999")
    assert auth.validate_init_data(tampered) is None


def test_missing_hash_fails():
    assert auth.validate_init_data("user=...&auth_date=123") is None


def test_empty_data_fails_when_required():
    # Без локального теста пустые данные отклоняются
    assert auth.validate_init_data("") is None


def test_local_test_allowed(db, monkeypatch):
    """В локальном режиме пустые данные дают синтетического пользователя."""
    monkeypatch.setattr(cfg.config, "ALLOW_LOCAL_TEST", True)
    result = auth.validate_init_data("")
    assert result is not None
    assert result[0] >= 1000000


def test_stale_auth_rejected(monkeypatch):
    """Устаревшие подписи отклоняются по auth_date."""
    monkeypatch.setattr(cfg.config, "AUTH_MAX_AGE_SECONDS", 60)
    # Эмулируем старую подпись напрямую (auth_date в прошлом)
    old_init = _make_stale_init_data()
    assert auth.validate_init_data(old_init) is None


def _make_stale_init_data():
    """Вспомогательная: подпись с auth_date 2 часа назад."""
    import json
    import urllib.parse
    import hashlib
    import hmac

    old_ts = str(int(time.time()) - 7200)
    user = json.dumps({"id": 777, "first_name": "Old"})
    check = {"user": user, "auth_date": old_ts}
    dcs = "\n".join(f"{k}={v}" for k, v in sorted(check.items()))
    secret = hmac.new(b"WebAppData", cfg.config.BOT_TOKEN.encode(), hashlib.sha256).digest()
    h = hmac.new(secret, dcs.encode(), hashlib.sha256).hexdigest()
    return urllib.parse.urlencode({"user": user, "auth_date": old_ts, "hash": h})


def test_wrong_bot_token_rejected():
    """Подпись, сделанная другим токеном, не проходит."""
    data = auth.make_test_init_data(12345)
    # меняем токен на сервере
    original = cfg.config.BOT_TOKEN
    cfg.config.BOT_TOKEN = "OTHER:token"
    try:
        assert auth.validate_init_data(data) is None
    finally:
        cfg.config.BOT_TOKEN = original