# -*- coding: utf-8 -*-
"""
Тесты админ-панели и системы банов.

Проверяем: выдачу ресурсов, бан/разбан, запрет бана админа, сброс прогресса,
статистику, а также что забаненный игрок получает 403 на игровых маршрутах.
"""

from __future__ import annotations

import pytest

from backend import admin as admin_logic
from backend import auth
from backend import game as g
from backend import economy as eco
from backend.config import config


def _bal(db, uid):
    return db._query_one("SELECT balance FROM balances WHERE user_id = ?", (uid,))["balance"]


# --- Права -------------------------------------------------------------------


def test_is_admin(monkeypatch):
    monkeypatch.setattr(config, "ADMIN_IDS", [111, 222])
    assert admin_logic.is_admin(111) is True
    assert admin_logic.is_admin(999) is False
    assert admin_logic.is_admin(None) is False


# --- Выдача ресурсов ---------------------------------------------------------


def test_grant_balance(db):
    g.ensure_player(db, 1, "Игрок")
    before = _bal(db, 1)
    res = admin_logic.grant(db, 1, "balance", amount=500)
    assert res["success"] is True
    assert _bal(db, 1) == before + 500


def test_grant_set_balance(db):
    g.ensure_player(db, 1, "Игрок")
    admin_logic.grant(db, 1, "set_balance", amount=7777)
    assert _bal(db, 1) == 7777


def test_grant_business_level(db):
    g.ensure_player(db, 1, "Игрок")
    res = admin_logic.grant(db, 1, "business", business_id="hotel", level=5)
    assert res["success"] is True
    lvl = db._query_one(
        "SELECT level FROM businesses WHERE user_id = ? AND business_id = ?", (1, "hotel")
    )["level"]
    assert lvl == 5


def test_grant_employee(db):
    g.ensure_player(db, 1, "Игрок")
    res = admin_logic.grant(db, 1, "employee", employee_id="director")
    assert res["success"] is True
    cnt = db._query_one(
        "SELECT count FROM employees WHERE user_id = ? AND employee_id = ?", (1, "director")
    )["count"]
    assert cnt == 1


def test_grant_everything(db):
    g.ensure_player(db, 1, "Игрок")
    before = _bal(db, 1)
    res = admin_logic.grant(db, 1, "everything")
    assert res["success"] is True
    # все предприятия открыты
    owned = db._query_one(
        "SELECT COUNT(*) AS c FROM businesses WHERE user_id = ? AND level > 0", (1,)
    )["c"]
    assert owned == len(eco.BUSINESSES)
    # все сотрудники наняты
    hired = db._query_one(
        "SELECT COUNT(*) AS c FROM employees WHERE user_id = ? AND count > 0", (1,)
    )["c"]
    assert hired == len(eco.EMPLOYEES)
    # +1 000 000 монет
    assert _bal(db, 1) >= before + 1_000_000


def test_grant_unknown_kind(db):
    g.ensure_player(db, 1, "Игрок")
    res = admin_logic.grant(db, 1, "hack_the_planet")
    assert res["success"] is False


# --- Баны --------------------------------------------------------------------


def test_ban_and_unban(db):
    g.ensure_player(db, 2, "Нарушитель")
    assert admin_logic.is_banned(db, 2) is False
    res = admin_logic.ban(db, 2, "чит")
    assert res["success"] is True
    assert admin_logic.is_banned(db, 2) is True
    admin_logic.unban(db, 2)
    assert admin_logic.is_banned(db, 2) is False


def test_cannot_ban_admin(db, monkeypatch):
    monkeypatch.setattr(config, "ADMIN_IDS", [42])
    g.ensure_player(db, 42, "Админ")
    res = admin_logic.ban(db, 42)
    assert res["success"] is False
    assert admin_logic.is_banned(db, 42) is False


def test_ban_unknown_user(db):
    res = admin_logic.ban(db, 999999)
    assert res["success"] is False


# --- Сброс прогресса ---------------------------------------------------------


def test_reset_progress(db):
    g.ensure_player(db, 3, "Игрок")
    g.grant_balance(db, 3, 100000)
    admin_logic.grant(db, 3, "everything")
    res = admin_logic.reset_progress(db, 3)
    assert res["success"] is True
    assert _bal(db, 3) == eco.START_BALANCE
    # осталось только стартовое предприятие
    owned = db._query_all(
        "SELECT business_id FROM businesses WHERE user_id = ? AND level > 0", (3,)
    )
    assert len(owned) == 1
    assert owned[0]["business_id"] == eco.STARTUP_BUSINESS_ID


def test_reset_cannot_reset_admin(db, monkeypatch):
    monkeypatch.setattr(config, "ADMIN_IDS", [77])
    g.ensure_player(db, 77, "Админ")
    res = admin_logic.reset_progress(db, 77)
    assert res["success"] is False


# --- Список и статистика -----------------------------------------------------


def test_list_users_search(db):
    g.ensure_player(db, 10, "Алиса")
    g.ensure_player(db, 11, "Боб")
    all_users = admin_logic.list_users(db)
    assert all_users["total"] >= 2

    by_id = admin_logic.list_users(db, "10")
    assert any(u["id"] == 10 for u in by_id["users"])

    by_name = admin_logic.list_users(db, "Боб")
    assert any(u["name"] == "Боб" for u in by_name["users"])


def test_stats(db):
    g.ensure_player(db, 20, "Игрок")
    st = admin_logic.stats(db)
    assert st["users"] >= 1
    assert "total_balance" in st
    assert st["admins"] == len(config.ADMIN_IDS)


# --- Проверка на уровне API (403 для забаненных) -----------------------------


@pytest.fixture()
def client(monkeypatch, db):
    """TestClient, использующий тестовую базу."""
    import backend.main as main

    monkeypatch.setattr(main, "get_db", lambda: db)
    from fastapi.testclient import TestClient

    return TestClient(main.app)


def test_api_me_forbidden_when_banned(client, db, monkeypatch):
    """Забаненный игрок получает 403 на игровых маршрутах."""
    monkeypatch.setattr(config, "BOT_TOKEN", "TEST:token-for-tests")
    uid = 31337
    g.ensure_player(db, uid, "Нарушитель")
    admin_logic.ban(db, uid, "тест")
    init = auth.make_test_init_data(uid)
    r = client.get("/api/me", headers={"Authorization": "tma " + init})
    assert r.status_code == 403


def test_api_admin_check(client, db, monkeypatch):
    """Обычный игрок не админ; админ — да."""
    monkeypatch.setattr(config, "BOT_TOKEN", "TEST:token-for-tests")
    monkeypatch.setattr(config, "ADMIN_IDS", [4242])
    g.ensure_player(db, 4242, "Админ")

    # Обычный пользователь
    init_user = auth.make_test_init_data(555)
    r1 = client.get("/api/admin/check", headers={"Authorization": "tma " + init_user})
    assert r1.json()["data"]["is_admin"] is False

    # Админ
    init_admin = auth.make_test_init_data(4242)
    r2 = client.get("/api/admin/check", headers={"Authorization": "tma " + init_admin})
    assert r2.json()["data"]["is_admin"] is True


def test_api_admin_endpoints_require_admin(client, db, monkeypatch):
    """Не-админ получает 403 на админ-маршрутах."""
    monkeypatch.setattr(config, "BOT_TOKEN", "TEST:token-for-tests")
    monkeypatch.setattr(config, "ADMIN_IDS", [4242])
    init_user = auth.make_test_init_data(555)
    r = client.get("/api/admin/stats", headers={"Authorization": "tma " + init_user})
    assert r.status_code == 403


def test_api_admin_grant_flow(client, db, monkeypatch):
    """Админ может выдать ресурсы через API."""
    monkeypatch.setattr(config, "BOT_TOKEN", "TEST:token-for-tests")
    monkeypatch.setattr(config, "ADMIN_IDS", [4242])
    g.ensure_player(db, 600, "Цель")
    init_admin = auth.make_test_init_data(4242)
    r = client.post(
        "/api/admin/grant",
        json={"user_id": 600, "kind": "balance", "amount": 2500},
        headers={"Authorization": "tma " + init_admin},
    )
    assert r.status_code == 200
    assert r.json()["ok"] is True
    assert _bal(db, 600) >= 2500