﻿# -*- coding: utf-8 -*-
"""
Тесты покупок: транзакционность, отказ при недостатке средств,
однократная выдача наград, защита от гонок.
"""

from __future__ import annotations

import threading

from backend import game as g


def test_insufficient_funds_does_not_change_balance(db):
    g.ensure_player(db, 1, "Игрок")
    before = g.get_me(db, 1, "Игрок")["balance"]
    g.buy_business(db, 1, "pizzeria")  # стоит 5000, не хватает
    after = g.get_me(db, 1, "Игрок")["balance"]
    assert after == before


def test_purchase_is_atomic(db):
    """Ошибка покупки не оставляет частичных изменений."""
    g.ensure_player(db, 1, "Игрок")
    g.grant_balance(db, 1, 20000)
    before = g.get_me(db, 1, "Игрок")["balance"]

    # Ошибочный запрос (несуществующий бизнес) — ничего не должно списаться
    res = g.buy_business(db, 1, "nonexistent")
    assert res["success"] is False
    assert g.get_me(db, 1, "Игрок")["balance"] == before


def test_claim_task_reward_once(db):
    """Награду за задание можно забрать только один раз."""
    g.ensure_player(db, 1, "Игрок")
    # Помечаем задание выполненным и пробуем забрать
    # Приводим прогресс: открыто предприятие -> задание open_business
    g.grant_balance(db, 1, 5000)
    g.buy_business(db, 1, "grocery_store")
    g.update_task_progress(db, 1, "business")

    tasks = g.get_tasks(db, 1)
    open_task = next((t for t in tasks if t["key"] == "open_business"), None)
    # активное задание может не содержаться в day-наборе, проверим его наличие
    if open_task and open_task["done"]:
        bal_before = g.get_me(db, 1, "Игрок")["balance"]
        res1 = g.claim_task(db, 1, "open_business")
        assert res1["success"] is True
        bal_mid = g.get_me(db, 1, "Игрок")["balance"]
        assert bal_mid > bal_before
        res2 = g.claim_task(db, 1, "open_business")
        assert res2["success"] is False
        assert g.get_me(db, 1, "Игрок")["balance"] == bal_mid


def test_achievement_reward_once(db):
    """Achievement награда выдаётся один раз."""
    g.ensure_player(db, 1, "Игрок")
    # Первое достижение — первый бизнес (лимонад уже есть) -> получим награду
    g.update_achievements(db, 1)
    bal1 = g.get_me(db, 1, "Игрок")["balance"]

    # Повторный вызов ничего не даст заново
    newly2 = g.update_achievements(db, 1)
    bal2 = g.get_me(db, 1, "Игрок")["balance"]
    assert bal2 == bal1
    assert len(newly2) == 0


def test_concurrent_purchases_no_overdraft(db):
    """
    Одновременные покупки не должны уводить баланс в минус.
    Запускаем много потоков, каждый пытается купить магазин (300).
    Их суммарно должно «пройти» ровно столько, сколько позволяет баланс.
    """
    g.ensure_player(db, 1, "Игрок")
    g.grant_balance(db, 1, 1000)  # баланс 1100, хватит на 3 покупки магазина

    results = []
    errors = []

    def do_buy():
        try:
            r = g.buy_business(db, 1, "grocery_store")
            results.append(r["success"])
        except Exception as e:  # pragma: no cover
            errors.append(e)

    threads = [threading.Thread(target=do_buy) for _ in range(20)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert not errors
    # Сколько успешных покупок совершилось
    successes = sum(1 for r in results if r)
    me = g.get_me(db, 1, "Игрок")
    # Главное: НЕ должно быть овердрафта (минусового баланса)
    assert me["balance"] >= 0
    # И нельзя купить больше, чем позволяет стартовый капитал:
    # даже с учётом наград за достижения, за одну операцию нельзя
    # было сделать покупок больше, чем floor(1100 / 300).
    assert successes <= 3


def test_no_double_income_on_parallel_collect(db, clock):
    """
    Параллельный сбор дохода не начисляет дважды за одни и те же секунды.
    """
    g.ensure_player(db, 1, "Игрок")
    g.grant_balance(db, 1, 0)
    with clock:
        clock.now += 60  # 1 минута
        results = []

        def collect():
            try:
                r = g.claim_income(db, 1)
                results.append(r["earned"])
            except Exception as e:
                results.append(e)

        threads = [threading.Thread(target=collect) for _ in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        total = sum(x if isinstance(x, int) else 0 for x in results)
        # доход 2/мин => 2 монеты суммарно, но не больше
        assert total == 2