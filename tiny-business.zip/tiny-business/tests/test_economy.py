﻿# -*- coding: utf-8 -*-
"""
Тесты игровой экономики: начальный баланс, доход, офлайн-начисления,
покупки, улучшения, сотрудники.
"""

from __future__ import annotations

from backend import economy as eco
from backend import game as g


def test_new_player_balance(db):
    g.ensure_player(db, 1, "Игрок")
    me = g.get_me(db, 1, "Игрок")
    assert me["balance"] == eco.START_BALANCE
    assert me["total_earned"] == 0


def test_new_player_has_lemonade(db):
    g.ensure_player(db, 1, "Игрок")
    me = g.get_me(db, 1, "Игрок")
    biz = {b["business_id"]: b for b in me["businesses"]}
    assert biz[eco.STARTUP_BUSINESS_ID]["owned"] is True
    assert biz[eco.STARTUP_BUSINESS_ID]["level"] == 1


def test_initial_income(db):
    g.ensure_player(db, 1, "Игрок")
    me = g.get_me(db, 1, "Игрок")
    assert me["money_per_min"] == eco.START_MONEY_PER_MIN


def test_business_income_formula(db):
    """Проверка формулы роста дохода с уровнем."""
    base = eco.BUSINESSES["lemonade_stand"].base_income
    lvl1 = eco.business_income(eco.BUSINESSES["lemonade_stand"], 1)
    lvl2 = eco.business_income(eco.BUSINESSES["lemonade_stand"], 2)
    assert lvl1 == base
    assert lvl2 > lvl1


def test_upgrade_cost_growth(db):
    """Цена улучшения должна расти примерно в 1.7 раза."""
    biz = eco.BUSINESSES["grocery_store"]
    c1 = eco.business_cost(biz, 1)
    c2 = eco.business_cost(biz, 2)
    assert c2 / c1 > 1.6
    assert c2 / c1 < 1.8


def test_offline_income_within_cap(db, clock):
    """
    Доход начисляется за прошедшее время, но не больше 8 часов.
    """
    g.ensure_player(db, 1, "Игрок")
    with clock:
        clock.now += 60 * 5  # прошло 5 минут
        res = g.claim_income(db, 1)
        # Доход 2/мин за 5 минут = 10 (integer rounding: 2*300/60=10)
        assert res["earned"] == 10
        assert res["applied_seconds"] == 300
        # last_income_at сдвинут — повторный сбор за те же секунды даст 0
        res2 = g.claim_income(db, 1)
        assert res2["earned"] == 0


def test_offline_cap_hours(db, clock):
    """
    Офлайн-доход ограничен 8 часами, не бесконечен.
    """
    g.ensure_player(db, 1, "Игрок")
    with clock:
        # Доход 2/мин * 480 мин = 960 монет за лимит
        clock.now += 20 * 60 * 60  # 20 часов
        res = g.claim_income(db, 1)
        # максимум за 8 часов
        assert res["earned"] == 2 * 8 * 60
        assert res["applied_seconds"] == g.OFFLINE_CAP_SECONDS


def test_offline_cap_cannot_be_farmed(db, clock):
    """
    Регресс-тест: лимит 8 часов НЕЛЬЗЯ обойти повторными вызовами сбора.

    Раньше last_income_at сдвигался только на начисленный период, поэтому
    после 20 часов отсутствия игрок мог собрать «остаток» вторым запросом.
    Теперь время фиксируется на now, и лишнее сгорает.
    """
    g.ensure_player(db, 1, "Игрок")
    with clock:
        clock.now += 20 * 60 * 60  # 20 часов отсутствия
        first = g.claim_income(db, 1)
        assert first["earned"] == 2 * 8 * 60  # только лимит

        # Повторные сборы не должны начислять «остаток» часов
        assert g.claim_income(db, 1)["earned"] == 0
        assert g.claim_income(db, 1)["earned"] == 0

        # Прошёл ещё час — снова начисляется, но заново не больше лимита
        clock.now += 60 * 60
        assert g.claim_income(db, 1)["earned"] == 2 * 60


def test_no_income_for_negative_time(db, clock):
    g.ensure_player(db, 1, "Игрок")
    with clock:
        clock.now -= 100  # время ушло назад
        res = g.claim_income(db, 1)
        assert res["earned"] == 0


def test_buy_business_success(db):
    g.ensure_player(db, 1, "Игрок")
    g.grant_balance(db, 1, 500)  # дадим сверх стартовых 100 → баланс 600
    res = g.buy_business(db, 1, "grocery_store")
    assert res["success"] is True
    me = g.get_me(db, 1, "Игрок")
    biz = {b["business_id"]: b for b in me["businesses"]}
    assert biz["grocery_store"]["owned"] is True
    # Стоимость покупки списана из баланса
    assert me["balance"] < 600
    # Игрок не ушёл в минус
    assert me["balance"] >= 0


def test_buy_business_insufficient(db):
    g.ensure_player(db, 1, "Игрок")
    # Баланс 100 < 300 — не хватает
    res = g.buy_business(db, 1, "grocery_store")
    assert res["success"] is False


def test_upgrade_business(db):
    g.ensure_player(db, 1, "Игрок")
    # Даем стартовому лимонаду деньги на улучшение
    g.grant_balance(db, 1, 2000)
    res = g.buy_business(db, 1, "lemonade_stand")
    assert res["success"] is True
    assert res["new_level"] == 2


def test_employee_buy_success(db):
    g.ensure_player(db, 1, "Игрок")
    g.grant_balance(db, 1, 300)
    res = g.buy_employee(db, 1, "seller")
    assert res["success"] is True
    me = g.get_me(db, 1, "Игрок")
    emp = {e["employee_id"]: e for e in me["employees"]}
    assert emp["seller"]["count"] == 1


def test_employee_cannot_buy_twice(db):
    g.ensure_player(db, 1, "Игрок")
    g.grant_balance(db, 1, 1000)
    assert g.buy_employee(db, 1, "seller")["success"] is True
    res = g.buy_employee(db, 1, "seller")
    assert res["success"] is False


def test_employee_bonus_affects_income(db):
    """Продавец +10% к доходу лимонада."""
    g.ensure_player(db, 1, "Игрок")
    base = g.money_per_minute(db.conn, 1)
    g.grant_balance(db, 1, 300)
    g.buy_employee(db, 1, "seller")
    after = g.money_per_minute(db.conn, 1)
    assert base == 2
    assert abs(after - int(2 * 1.10)) <= 1


def test_progress_saved_after_restart(db):
    """Прогресс сохраняется: повторное открытие БД показывает те же данные."""
    g.ensure_player(db, 1, "Игрок")
    g.grant_balance(db, 1, 500)
    g.buy_business(db, 1, "grocery_store")

    # Закрываем текущую базу и открываем ту же файл снова
    db.close()
    path = db._path
    import backend.game as g2
    from backend.database import Database

    db2 = Database(path)
    db2.connect()
    db2.init_schema()
    me = g2.get_me(db2, 1, "Игрок")
    assert me["balance"] >= 0
    biz = {b["business_id"]: b for b in me["businesses"]}
    assert biz["grocery_store"]["owned"] is True
    assert biz["grocery_store"]["level"] == 1
    db2.close()