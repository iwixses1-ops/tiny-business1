# -*- coding: utf-8 -*-
"""
Тесты донат-магазина, заявок, премиума и рассылки.

Проверяем:
  - каталог услуг;
  - создание заявки и её появление у админа;
  - подтверждение = автоматическая выдача награды (монеты/премиум);
  - повторное подтверждение невозможно (нет двойной выдачи);
  - отклонение заявки (+50 премиума опционально нет).
"""

from __future__ import annotations

import time

import pytest

from backend import game as g
from backend import shop as shop_logic
from backend import economy as eco
from backend.config import config


def _bal(db, uid):
    return db._query_one("SELECT balance FROM balances WHERE user_id = ?", (uid,))["balance"]


def _prem(db, uid):
    return db._query_one("SELECT premium_until FROM users WHERE id = ?", (uid,))["premium_until"]


@pytest.fixture(autouse=True)
def _env(monkeypatch):
    monkeypatch.setattr(config, "OWNER_USERNAME", "boss")
    monkeypatch.setattr(config, "OWNER_ID", 5000)


# --- Каталог -----------------------------------------------------------------


def test_services_catalog():
    svcs = shop_logic.list_services()
    assert len(svcs) >= 3
    # все цены > 0 и есть описания
    for s in svcs:
        assert s["price"] > 0
        assert s["description"]
    # упорядочены по цене
    prices = [s["price"] for s in svcs]
    assert prices == sorted(prices)


def test_prices_in_required_range():
    """Цены услуг обязаны быть в диапазоне 25–250 ₽."""
    svcs = shop_logic.list_services()
    assert svcs, "каталог не должен быть пустым"
    for s in svcs:
        assert 25 <= s["price"] <= 250, (
            f"{s['name']}: {s['price']} ₽ — вне диапазона 25–250 ₽"
        )
    # границы диапазона реально задействованы (самая дешёвая и самая дорогая)
    assert min(s["price"] for s in svcs) == 25
    assert max(s["price"] for s in svcs) == 250


def test_unknown_service_order_fails(db):
    g.ensure_player(db, 1, "Игрок")
    res = shop_logic.create_order(db, 1, "no_such_service")
    assert res["success"] is False


def test_create_order_no_owner():
    # без владельца магазин не работает
    from backend.config import config as c
    c.OWNER_USERNAME = ""
    c.OWNER_ID = None
    assert not c.owner_link()


# --- Заявка ------------------------------------------------------------------


def test_create_order_and_appears_in_admin(db):
    g.ensure_player(db, 1, "Покупатель")
    res = shop_logic.create_order(db, 1, "coins_small")
    assert res["success"] is True
    order_id = res["order"]["id"]
    assert res["owner_link"] == "https://t.me/boss"

    # заявка у админа (pending)
    data = shop_logic.admin_list_orders(db, status="pending")
    assert any(o["id"] == order_id for o in data["orders"])
    # у игрока в истории
    mine = shop_logic.list_user_orders(db, 1)
    assert any(o["id"] == order_id for o in mine)


def test_confirm_coin_order_delivers(db):
    uid = 2
    g.ensure_player(db, uid, "Игрок")
    before = _bal(db, uid)
    res = shop_logic.create_order(db, uid, "coins_big")  # 1 000 000
    order_id = res["order"]["id"]

    confirm = shop_logic.confirm_order(db, admin_id=config.ADMIN_IDS[0] if config.ADMIN_IDS else 99, order_id=order_id)
    assert confirm["success"] is True
    assert _bal(db, uid) - before >= 1_000_000


def test_confirm_order_only_once(db):
    uid = 3
    g.ensure_player(db, uid, "Игрок")
    before = _bal(db, uid)
    order_id = shop_logic.create_order(db, uid, "coins_medium")["order"]["id"]

    r1 = shop_logic.confirm_order(db, 99, order_id)
    assert r1["success"] is True
    mid = _bal(db, uid)
    assert mid > before

    r2 = shop_logic.confirm_order(db, 99, order_id)
    assert r2["success"] is False          # повторная выдача запрещена
    assert _bal(db, uid) == mid            # баланс не изменился повторно


def test_premium_order_adds_time(db):
    uid = 4
    g.ensure_player(db, uid, "Игрок")
    order_id = shop_logic.create_order(db, uid, "premium_7")["order"]["id"]
    assert _prem(db, uid) == 0
    res = shop_logic.confirm_order(db, 99, order_id)
    assert res["success"] is True
    # премиум на 7 дней вперёд
    days = (_prem(db, uid) - int(time.time())) / 86400
    assert days >= 6.9


def test_decline_order_no_reward(db):
    uid = 5
    g.ensure_player(db, uid, "Игрок")
    before = _bal(db, uid)
    order_id = shop_logic.create_order(db, uid, "coins_small")["order"]["id"]
    res = shop_logic.decline_order(db, 99, order_id)
    assert res["success"] is True
    assert _bal(db, uid) == before
    # ставим статус declined
    st = db._query_one("SELECT status FROM orders WHERE id = ?", (order_id,))["status"]
    assert st == "declined"


def test_order_limit_per_user(db):
    """Не больше 5 незавершённых заявок у одного игрока."""
    uid = 6
    g.ensure_player(db, uid, "Игрок")
    for _ in range(5):
        assert shop_logic.create_order(db, uid, "coins_small")["success"] is True
    # шестая не проходит
    res = shop_logic.create_order(db, uid, "coins_small")
    assert res["success"] is False


def test_premium_multiplies_income(db):
    """Премиум даёт множитель дохода x1.5."""
    uid = 7
    g.ensure_player(db, uid, "Игрок")
    base = g.money_per_minute(db.conn, uid)
    with db.transaction() as con:
        con.execute(
            "UPDATE users SET premium_until = ? WHERE id = ?",
            (int(time.time()) + 3600, uid),
        )
    after = g.money_per_minute(db.conn, uid)
    assert after == round(base * eco.PREMIUM_INCOME_MULTIPLIER)
    assert g.is_premium_active(db.conn, uid) is True


# --- Рассылка ----------------------------------------------------------------


def test_broadcast_create_and_list(db):
    res = broadcast_create_helper(db, 1, "Привет всем!")
    assert res["success"] is True
    assert res["broadcast_id"] >= 1
    lst = broadcast_list_helper(db)
    assert len(lst) >= 1
    assert lst[0]["text"] == "Привет всем!"


def test_broadcast_pending_processing(db, monkeypatch):
    """Воркер обрабатывает рассылку, помечая получателей (идемпотентно)."""
    from backend import broadcast as b

    g.ensure_player(db, 11, "Алиса")
    g.ensure_player(db, 12, "Боб")
    bid = b.broadcast_create(db, 1, "test")["broadcast_id"]

    bc = b.get_pending_broadcast(db)
    assert bc is not None and bc["id"] == bid

    b.mark_broadcast_running(db, bid)
    targets = b.broadcast_targets(db, bid)
    assert 11 in targets and 12 in targets

    # моделируем отправку двум игрокам
    b.add_broadcast_recipient(db, bid, 11)
    b.add_broadcast_recipient(db, bid, 12)

    # повторная «отправка» тем же игрокам — уже_sent=True
    assert b.already_sent(db, bid, 11) is True
    assert b.already_sent(db, bid, 12) is True
    # новый игрок ещё нет
    g.ensure_player(db, 13, "Вика")
    assert b.already_sent(db, bid, 13) is False

    b.finish_broadcast(db, bid, 0)
    st = db._query_one("SELECT * FROM broadcasts WHERE id = ?", (bid,))["status"]
    assert st == "done"
    assert db._query_one("SELECT sent FROM broadcasts WHERE id = ?", (bid,))["sent"] == 2


# --- Хелперы (чтобы не зависеть от нейминга импорта в main) -----------------

def broadcast_create_helper(db, admin_id, text):
    from backend import broadcast as b
    return b.broadcast_create(db, admin_id, text)


def broadcast_list_helper(db):
    from backend import broadcast as b
    return b.broadcast_list(db)