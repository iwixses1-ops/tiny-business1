# -*- coding: utf-8 -*-
"""Пакет tests для pytest."""