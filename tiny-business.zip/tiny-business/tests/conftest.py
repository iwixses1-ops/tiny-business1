# -*- coding: utf-8 -*-
"""
Общие fixtures для pytest: тестовая база и управление clock (времени).
"""

from __future__ import annotations

import os
import sys
import time

import pytest

# Позволяем импортировать пакеты проекта (backend.*) из папки выше
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Принудительно используем тестовый режим аутентификации
os.environ.setdefault("ALLOW_LOCAL_TEST", "true")
os.environ.setdefault("BOT_TOKEN", "TEST:token-for-tests")

from backend.database import Database  # noqa: E402


@pytest.fixture()
def db(tmp_path):
    """Свежая изолированная база для каждого теста."""
    path = tmp_path / "test.db"
    test_db = Database(str(path))
    test_db.connect()
    test_db.init_schema()
    yield test_db
    test_db.close()


@pytest.fixture()
def clock():
    """Позволяет переопределять время через патчинг time.time() в game.py.

    Возвращает объект с .now, который можно менять: clock.now += 60.
    game.py использует глобальный time.time; заменяем его локально.
    """
    class Clock:
        def __init__(self):
            self.now = int(time.time())

        def __enter__(self):
            import backend.game as g
            self._orig = g.time.time
            g.time.time = lambda: self.now
            return self

        def __exit__(self, *a):
            import backend.game as g
            g.time.time = self._orig

    return Clock()


def make_user(db: Database, uid: int, name: str = "Игрок"):
    """Создаёт игрока и возвращает состояние."""
    import backend.game as g

    g.ensure_player(db, uid, name)
    return uid