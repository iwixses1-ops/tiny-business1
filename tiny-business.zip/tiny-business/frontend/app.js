/* Tiny Business — клиент Mini App.
   Работает в Telegram (через официальный Telegram Web Apps SDK) и в обычном
   браузере (режим разработки). Вся игровая логика и цены НА СЕРВЕРЕ;
   здесь — только отображение и отправка действий.

   API-сервер: возвращает {ok, data} или {ok:false, error}.
*/

const API_BASE = (window.TB_API_BASE && window.TB_API_BASE !== "__API_BASE__")
  ? window.TB_API_BASE
  : ""; // пусто = тот же origin, что раздаёт frontend

// --- Telegram SDK ---------------------------------------------------------

const tg = (window.Telegram && window.Telegram.WebApp) ? window.Telegram.WebApp : null;
const isTelegram = !!tg;

function initTelegram() {
  if (!tg) return;
  try {
    tg.ready();
    tg.expand();
    tg.setHeaderColor && tg.setHeaderColor("#0f1b3d");
    if (tg.setBackgroundColor) tg.setBackgroundColor("#0f1b3d");
    if (tg.colorScheme === "dark") {
      document.body.classList.add("tg-dark");
    }
  } catch (e) { /* не критично */ }
}

function getInitData() {
  // В Telegram берём у SDK; в браузере — из window (устанавливается
  // тестовым скриптом во время разработки).
  if (tg && tg.initData) return tg.initData;
  return window.TB_TEST_INIT_DATA || "";
}

// --- Состояние и элементы --------------------------------------------------

let state = {
  balance: 0, totalEarned: 0, moneyPerMin: 0,
  businesses: [], employees: [], user: null,
  offlinePending: 0, offlineSeconds: 0,
  newlyAchievements: [],
};

let currentView = "home";

const $ = (id) => document.getElementById(id);

// --- Форматирование --------------------------------------------------------

function fmt(n) {
  const s = String(n);
  return s.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}

// --- HTTP ------------------------------------------------------------------

async function api(path, method = "GET", body = null) {
  const headers = { "Content-Type": "application/json" };
  const initData = getInitData();
  if (initData) {
    headers["Authorization"] = "tma " + initData;
  }
  const opts = { method, headers };
  if (body) opts.body = JSON.stringify(body);

  let res;
  try {
    res = await fetch(API_BASE + path, opts);
  } catch (e) {
    throw { ok: false, error: "Сеть недоступна" };
  }
  let json;
  try { json = await res.json(); } catch (e) { json = { ok: false, error: "Ошибка сервера" }; }
  return json;
}

// --- Всплывающие уведомления ----------------------------------------------

let toastTimer = null;
function toast(msg) {
  const el = $("toast");
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
}

// --- Навигация ------------------------------------------------------------

function switchView(view) {
  currentView = view;
  document.querySelectorAll(".nav-btn").forEach(b => {
    b.classList.toggle("active", b.dataset.nav === view);
  });
  render();
}

// --- Bootstrap -------------------------------------------------------------

async function boot() {
  initTelegram();
  bindNav();
  $("collect-btn").addEventListener("click", collectIncome);
  $("theme-toggle").addEventListener("click", toggleTheme);

  await checkAdmin();

  try {
    await loadState();
    render();
  } catch (e) {
    toast("Ошибка загрузки: " + (e && e.error ? e.error : e));
  }
}

async function checkAdmin() {
  // Показываем вкладку «Админ» только тем, кто в ADMIN_IDS на сервере.
  try {
    const r = await api("/api/admin/check");
    if (r.ok && r.data && r.data.is_admin) {
      state.isAdmin = true;
      const btn = document.getElementById("nav-admin");
      if (btn) btn.style.display = "";
    }
  } catch (e) { /* не админ или ошибка — вкладки не будет */ }
}

function bindNav() {
  document.querySelectorAll(".nav-btn").forEach(b => {
    b.addEventListener("click", () => switchView(b.dataset.nav));
  });
}

async function loadState() {
  const r = await api("/api/me");
  if (!r.ok) throw r;
  state = { ...state, ...r.data };
  if (state.newlyAchievements && state.newlyAchievements.length) {
    // Показываем только что открытые достижения
    state.newlyAchievements.forEach(a => toast(`🏆 ${a.title} +${a.reward}`));
    state.newlyAchievements = [];
  }
}

async function collectIncome() {
  const btn = $("collect-btn");
  btn.disabled = true;
  try {
    const r = await api("/api/collect", "POST");
    if (r.ok && r.data && r.data.earned > 0) {
      toast(`💵 Собрано +${fmt(r.data.earned)} монет`);
      state.balance = r.data.balance;
    } else if (r.ok) {
      toast("Пока нет прибыли");
    }
    updateHeader();
  } catch (e) {
    toast("Не удалось собрать");
  } finally {
    btn.disabled = false;
  }
}

// --- Рендер ---------------------------------------------------------------

function render() {
  updateHeader();
  const container = $("view-container");
  switch (currentView) {
    case "home": container.innerHTML = renderHome(); break;
    case "businesses": renderBusinesses(container); break;
    case "employees": renderEmployees(container); break;
    case "tasks": renderTasks(container); break;
    case "achievements": renderAchievements(container); break;
    case "leaderboard": renderLeaderboard(container); break;
    case "profile": renderProfile(container); break;
    case "shop": renderShop(container); break;
    case "admin": renderAdmin(container); break;
  }
}

function updateHeader() {
  $("balance-value").textContent = fmt(state.balance);
  $("income-text").textContent = "+" + fmt(state.moneyPerMin) + " / мин";
}

function renderHome() {
  // Главное (самое доходное) предприятие
  const main = [...state.businesses].filter(b => b.owned).sort((a, b) => b.income - a.income)[0];
  // Доступные улучшения/покупки
  const afford = state.businesses.filter(b => state.balance >= b.next_cost);

  return `
    <div class="view">
      <div class="section-title">🏪 Главное предприятие</div>
      ${main ? `
        <div class="card card-row">
          <div class="card-emoji">${main.emoji}</div>
          <div class="card-info">
            <div class="card-name">${main.name}</div>
            <div class="card-sub">Уровень ${main.level} · +${fmt(main.income)}/мин</div>
          </div>
        </div>
      ` : `<div class="card muted">Открой первое предприятие в разделе «Бизнес»</div>`}

      <div class="section-title">💡 Доступные улучшения</div>
      ${afford.length ? afford.slice(0, 4).map(b => `
        <div class="card card-row">
          <div class="card-emoji">${b.emoji}</div>
          <div class="card-info">
            <div class="card-name">${b.name}${b.owned ? " · ур. " + b.level : ""}</div>
            <div class="card-sub">${b.owned ? "+доход" : "Открыть"}</div>
          </div>
          <button class="btn-primary" style="margin-top:0;width:auto;padding:10px 14px"
            onclick="buyBusiness('${b.business_id}')">${fmt(b.next_cost)} 🪙</button>
        </div>
      `).join("") : `<div class="card muted">Пока ничего не доступно — заработай больше монет</div>`}

      <div class="section-title">📈 Прогресс</div>
      <div class="stat-grid">
        <div class="stat-box"><div class="stat-num">${state.businesses.filter(b=>b.owned).length}</div><div class="stat-label">Бизнесов</div></div>
        <div class="stat-box"><div class="stat-num">${state.employees.filter(e=>e.count>0).length}</div><div class="stat-label">Сотрудников</div></div>
        <div class="stat-box"><div class="stat-num">${fmt(state.totalEarned)}</div><div class="stat-label">Всего заработано</div></div>
        <div class="stat-box"><div class="stat-num">+${fmt(state.moneyPerMin)}</div><div class="stat-label">/ минуту</div></div>
      </div>
    </div>`;
}

async function renderBusinesses(container) {
  container.innerHTML = `<div class="view"><div class="muted" style="padding:20px;text-align:center">Загрузка…</div></div>`;
  try {
    const r = await api("/api/businesses");
    if (!r.ok) throw r;
    container.innerHTML = `<div class="view">
      <div class="section-title">🏪 Предприятия</div>
      ${r.data.businesses.map(b => `
        <div class="card">
          <div class="card-row">
            <div class="card-emoji">${b.emoji}</div>
            <div class="card-info">
              <div class="card-name">${b.name}</div>
              <div class="card-sub">${b.description}</div>
              ${b.owned ?
                `<div class="card-sub">Уровень <b>${b.level}</b> · +${fmt(b.income)}/мин</div>` :
                `<div class="card-sub">Открытие: ${fmt(b.base_cost)} 🪙</div>`}
            </div>
          </div>
          <button class="btn-primary" onclick="buyBusiness('${b.business_id}')"
            ${state.balance < b.next_cost ? "disabled" : ""}>
            ${b.owned ? `⬆️ Улучшить (${fmt(b.next_cost)} 🪙)` : `🚀 Открыть (${fmt(b.next_cost)} 🪙)`}
          </button>
        </div>
      `).join("")}
    </div>`;
  } catch (e) {
    container.innerHTML = `<div class="view"><div class="card muted">Ошибка загрузки</div></div>`;
  }
}

async function renderEmployees(container) {
  container.innerHTML = `<div class="view"><div class="muted" style="padding:20px;text-align:center">Загрузка…</div></div>`;
  try {
    const r = await api("/api/me");
    if (!r.ok) throw r;
    const emps = r.data.employees;
    container.innerHTML = `<div class="view">
      <div class="section-title">🤝 Сотрудники</div>
      ${emps.map(e => `
        <div class="card">
          <div class="card-row">
            <div class="card-emoji">${e.emoji}</div>
            <div class="card-info">
              <div class="card-name">${e.name}</div>
              <div class="card-sub">${e.bonus_description}</div>
              <div class="card-sub">${e.count > 0 ? "Нанят ✅" : "Цена: " + fmt(e.cost) + " 🪙"}</div>
            </div>
          </div>
          ${e.count === 0 ? `<button class="btn-primary" onclick="hireEmployee('${e.employee_id}')"
            ${state.balance < e.cost ? "disabled" : ""}>Нанять (${fmt(e.cost)} 🪙)</button>`
            : `<div class="badge" style="margin-top:8px">Уже в команде</div>`}
        </div>
      `).join("")}
    </div>`;
  } catch (e) {
    container.innerHTML = `<div class="view"><div class="card muted">Ошибка загрузки</div></div>`;
  }
}

async function renderTasks(container) {
  container.innerHTML = `<div class="view"><div class="muted" style="padding:20px;text-align:center">Загрузка…</div></div>`;
  try {
    const r = await api("/api/tasks");
    if (!r.ok) throw r;
    container.innerHTML = `<div class="view">
      <div class="section-title">📋 Задания на сегодня</div>
      <div class="muted" style="font-size:12px;margin-bottom:10px">Обновляются каждый день (UTC)</div>
      ${r.data.tasks.map(t => {
        const pct = Math.min(100, Math.round(t.progress / t.target * 100));
        return `<div class="card task-card">
          <div class="task-body">
            <div class="task-title">${t.emoji} ${t.title}</div>
            <div class="card-sub">${t.description}</div>
            <div class="task-reward">Награда: ${fmt(t.reward)} 🪙</div>
            <div class="progress-bar"><div class="progress-fill" style="width:${pct}%"></div></div>
            <div class="muted" style="font-size:11px;margin-top:3px">${Math.min(t.progress,t.target)} / ${t.target}</div>
          </div>
          <div>
            ${t.claimed ? `<div class="task-done">Получено ✓</div>`
              : t.done ? `<button class="btn-primary" style="margin-top:0;width:auto;padding:10px 14px" onclick="claimTask('${t.key}')">Забрать</button>`
              : `<div class="badge">В процессе</div>`}
          </div>
        </div>`;
      }).join("")}
    </div>`;
  } catch (e) {
    container.innerHTML = `<div class="view"><div class="card muted">Ошибка загрузки</div></div>`;
  }
}

async function renderAchievements(container) {
  container.innerHTML = `<div class="view"><div class="muted" style="padding:20px;text-align:center">Загрузка…</div></div>`;
  try {
    const r = await api("/api/achievements");
    if (!r.ok) throw r;
    container.innerHTML = `<div class="view">
      <div class="section-title">🏆 Достижения</div>
      ${r.data.achievements.map(a => `
        <div class="card card-row">
          <div class="card-emoji" style="opacity:${a.done ? 1 : .35}">${a.emoji}</div>
          <div class="card-info">
            <div class="card-name">${a.title}</div>
            <div class="card-sub">${a.description}</div>
            <div class="task-reward">+${fmt(a.reward)} 🪙</div>
          </div>
          <div>${a.claimed ? `<div class="task-done">✓</div>` : `<div class="badge">${a.done?"Выполнено":"Впереди"}</div>`}</div>
        </div>
      `).join("")}
    </div>`;
  } catch (e) {
    container.innerHTML = `<div class="view"><div class="card muted">Ошибка</div></div>`;
  }
}

async function renderLeaderboard(container) {
  container.innerHTML = `<div class="view"><div class="muted" style="padding:20px;text-align:center">Загрузка…</div></div>`;
  try {
    const r = await api("/api/leaderboard");
    if (!r.ok) throw r;
    const medals = ["🥇","🥈","🥉"];
    container.innerHTML = `<div class="view">
      <div class="section-title">📊 Рейтинг</div>
      ${r.data.rows.map(row => `
        <div class="card leader-row ${r.data.player && row.position===r.data.player.position ? "you-highlight" : ""}">
          <div class="leader-pos">${medals[row.position-1]||row.position}</div>
          <div class="leader-name">${escapeHtml(row.name)}</div>
          <div class="leader-bal">${fmt(row.balance)} 🪙</div>
        </div>
      `).join("")}
      ${r.data.player && r.data.player.position > r.data.rows.length ? `
        <div class="card leader-row you-highlight">
          <div class="leader-pos">${r.data.player.position}</div>
          <div class="leader-name">${escapeHtml(r.data.player.name)} (ты)</div>
          <div class="leader-bal">${fmt(r.data.player.balance)} 🪙</div>
        </div>` : ""}
    </div>`;
  } catch (e) { container.innerHTML = `<div class="card muted">Ошибка</div>`; }
}

async function renderProfile(container) {
  container.innerHTML = `<div class="view"><div class="muted" style="padding:20px;text-align:center">Загрузка…</div></div>`;
  try {
    const me = await api("/api/me");
    const ref = await api("/api/referral");
    if (!me.ok) throw me;
    const u = me.data.user;
    container.innerHTML = `<div class="view">
      <div class="section-title">👤 Профиль</div>
      <div class="card" style="text-align:center">
        <div style="font-size:40px">👑</div>
        <div style="font-weight:800;font-size:18px;margin:6px 0">${escapeHtml(u.name)}</div>
        <div class="muted">ID: ${u.id}</div>
      </div>
      <div class="section-title">Статистика</div>
      <div class="stat-grid">
        <div class="stat-box"><div class="stat-num">${fmt(me.data.balance)}</div><div class="stat-label">Баланс</div></div>
        <div class="stat-box"><div class="stat-num">${fmt(me.data.totalEarned)}</div><div class="stat-label">Заработано</div></div>
        <div class="stat-box"><div class="stat-num">+${fmt(me.data.moneyPerMin)}</div><div class="stat-label">/ мин</div></div>
        <div class="stat-box"><div class="stat-num">${me.data.businesses.filter(b=>b.owned).length}</div><div class="stat-label">Бизнесов</div></div>
      </div>
      ${ref.ok && ref.data ? `
        <div class="section-title">👥 Пригласи друга</div>
        <div class="card">
          <div class="card-sub">Получай ${fmt(ref.data.reward)} монет за каждого друга, который начал играть.</div>
          <div class="card-sub" style="margin-top:6px;word-break:break-all">${ref.data.referral_link}</div>
          <button class="btn-primary" onclick="copyReferral('${ref.data.referral_link}')">📋 Скопировать ссылку</button>
        </div>
        <div class="card muted" style="text-align:center">Приглашено друзей: <b>${ref.data.invited_count}</b></div>
      ` : ""}
    </div>`;
  } catch (e) {
    container.innerHTML = `<div class="card muted">Ошибка загрузки профиля</div>`;
  }
}

// --- Действия -------------------------------------------------------------

async function buyBusiness(id) {
  const r = await api(`/api/businesses/${id}/buy`, "POST");
  if (r.ok) {
    toast("🏪 " + r.data.message);
    state.balance = r.data.balance;
    await loadState();
    render();
  } else {
    toast(r.error || "Не удалось");
  }
}

async function hireEmployee(id) {
  const r = await api(`/api/employees/${id}/buy`, "POST");
  if (r.ok) {
    toast("🤝 " + r.data.message);
    state.balance = r.data.balance;
    await loadState();
    render();
  } else {
    toast(r.error || "Не удалось");
  }
}

async function claimTask(key) {
  const r = await api(`/api/tasks/${key}/claim`, "POST");
  if (r.ok) {
    toast("✅ " + r.data.message);
    state.balance = r.data.balance;
    await loadState();
    render();
  } else {
    toast(r.error || "Не удалось");
  }
}

function copyReferral(link) {
  const done = () => toast("Ссылка скопирована");
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(link).then(done).catch(() => fallbackCopy(link));
  } else {
    fallbackCopy(link);
  }
}
function fallbackCopy(text) {
  const ta = document.createElement("textarea");
  ta.value = text; document.body.appendChild(ta); ta.select();
  try { document.execCommand("copy"); toast("Ссылка скопирована"); }
  catch(e) { prompt("Скопируй ссылку вручную:", text); }
  document.body.removeChild(ta);
}

function toggleTheme() {
  document.body.classList.toggle("alt-theme");
  const isAlt = document.body.classList.contains("alt-theme");
  $("theme-toggle").textContent = isAlt ? "🌞" : "🌓";
  if (tg && tg.setHeaderColor) tg.setHeaderColor(isAlt ? "#121212" : "#0f1b3d");
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c =>
    ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
}

// --- Донат-магазин ----------------------------------------------------------

async function renderShop(container) {
  container.innerHTML = `<div class="view"><div class="muted" style="padding:20px;text-align:center">Загрузка…</div></div>`;

  let services = [], ownerLink = "", orders = [];
  try {
    const rs = await api("/api/shop/services");
    if (rs.ok) { services = rs.data.services; ownerLink = rs.data.owner_link || ""; }
    const ro = await api("/api/shop/orders");
    if (ro.ok) orders = ro.data.orders;
  } catch (e) { /* покажем заглушку */ }

  // Статус премиума
  const premActive = state.premium_active;
  const premRemain = state.premium_remaining || 0;
  const premDays = Math.ceil(premRemain / 86400);

  const premiumBanner = `
    <div class="card ${premActive ? "" : "muted"}" style="text-align:center">
      ${premActive
        ? `⭐ <b>Премиум активен</b> — доход x1.5. Осталось: ${fmt(premDays)} дн.`
        : "⭐ Премиум не активен. Включи множитель дохода x1.5!"}
    </div>`;

  const listHtml = services.map(s => `
    <div class="card">
      <div class="card-row">
        <div class="card-emoji">${s.emoji}</div>
        <div class="card-info">
          <div class="card-name">${s.name} ${s.badge ? `<span class="badge">${escapeHtml(s.badge)}</span>` : ""}</div>
          <div class="card-sub" style="white-space:pre-line">${escapeHtml(s.description)}</div>
          <div class="card-sub" style="margin-top:6px">💰 <b>${s.price} ₽</b></div>
        </div>
      </div>
      <button class="btn-primary" onclick="shopBuy('${s.id}')">Купить за ${s.price} ₽</button>
    </div>
  `).join("") || `<div class="card muted">Магазин пока пуст</div>`;

  const ordersHtml = orders.length ? `
    <div class="section-title">📦 Мои заявки</div>
    ${orders.map(o => `
      <div class="card card-row ${o.status === 'completed' ? '' : 'muted'}">
        <div class="card-info">
          <div class="card-name">${escapeHtml(o.service_name)} · ${o.price} ₽</div>
          <div class="card-sub">Заявка #${o.id} ·
            ${o.status === 'pending' ? '⏳ ожидает оплаты' : o.status === 'completed' ? '✅ выдано' : '❌ отклонено'}</div>
        </div>
      </div>`).join("")}
  ` : "";

  container.innerHTML = `
    <div class="view">
      <div class="section-title">🛍️ Донат-магазин</div>
      <div class="muted" style="font-size:12px;margin-bottom:10px">
        Покупки не обязательны. Оплата — вручную у владельца; товар выдаётся после подтверждения.
      </div>
      ${premiumBanner}
      ${listHtml}
      ${ordersHtml}
      <div class="card muted" style="text-align:center;font-size:12px">
        🔒 Без казино и вывода монет в деньги — только игровые товары.
      </div>
    </div>`;
}

async function shopBuy(serviceId) {
  const r = await api("/api/shop/buy", "POST", { service_id: serviceId });
  if (!r.ok) { toast("⛔ " + (r.error || "Не удалось создать заявку")); return; }
  const d = r.data;
  const link = d.owner_link || "";
  const instr = (d.pay_instruction || "").replace(/\n/g, "\n");
  // Тост + попытка открыть владельца
  toast(`✅ Заявка #${d.order.id} создана! Напиши владельцу и оплати.`);
  if (link && tg && tg.openTelegramLink) {
    try { tg.openTelegramLink(link); } catch(e) {}
  } else if (link) {
    window.open(link, "_blank");
  }
  await loadState();
  render();
}

// --- Админ-панель (видна только администраторам) --------------------------

state.adminOffset = 0;
state.adminQuery = "";
state.adminTab = "users";      // users | orders | broadcast
state.ordersOffset = 0;
state.ordersStatus = "";

async function renderAdmin(container) {
  if (!state.isAdmin) {
    container.innerHTML = `<div class="view"><div class="admin-banner">⛔ Доступ только для администраторов</div></div>`;
    return;
  }
  const tabs = `
    <div class="admin-tabs">
      <button class="${state.adminTab === 'users' ? 'active' : ''}" onclick="adminSetTab('users')">👥 Игроки</button>
      <button class="${state.adminTab === 'orders' ? 'active' : ''}" onclick="adminSetTab('orders')">🧾 Заявки</button>
      <button class="${state.adminTab === 'broadcast' ? 'active' : ''}" onclick="adminSetTab('broadcast')">📣 Рассылка</button>
    </div>`;
  if (state.adminTab === "orders") { container.innerHTML = `<div class="view">${tabs}</div>`; await adminRenderOrders(container, tabs); }
  else if (state.adminTab === "broadcast") { container.innerHTML = `<div class="view">${tabs}</div>`; await adminRenderBroadcast(container, tabs); }
  else { container.innerHTML = `<div class="view">${tabs}</div>`; await adminRenderUsers(container, tabs); }
}

function adminSetTab(tab) {
  state.adminTab = tab;
  renderAdmin(document.getElementById("view-container"));
}

async function adminRenderUsers(container, tabs) {
  container.innerHTML = `<div class="view">${tabs}<div class="muted" style="padding:20px;text-align:center">Загрузка…</div></div>`;
  let stats = null, users = null;
  try {
    const rs = await api("/api/admin/stats");
    if (rs.ok) stats = rs.data;
    const ru = await api(`/api/admin/users?q=${encodeURIComponent(state.adminQuery)}&limit=10&offset=${state.adminOffset}`);
    if (ru.ok) users = ru.data;
  } catch (e) { /* покажем что есть */ }

  const statsHtml = stats ? `
    <div class="admin-stats">
      <div class="admin-stat"><div class="n">${fmt(stats.users)}</div><div class="l">Игроков</div></div>
      <div class="admin-stat"><div class="n">${fmt(stats.banned)}</div><div class="l">Забанено</div></div>
      <div class="admin-stat"><div class="n">${fmt(stats.total_balance)}</div><div class="l">Монет в игре</div></div>
      <div class="admin-stat"><div class="n">${fmt(stats.businesses)}</div><div class="l">Предприятий</div></div>
    </div>` : "";

  const listHtml = users ? users.users.map(u => `
    <div class="card admin-user ${u.banned ? "banned" : ""}">
      <div class="card-row">
        <div class="card-emoji">${u.is_admin ? "🛡" : "👤"}</div>
        <div class="card-info">
          <div class="card-name">${escapeHtml(u.name || ("Игрок " + u.id))}</div>
          <div class="card-sub">ID: ${u.id}${u.is_admin ? " · админ" : ""}${u.banned ? " · 🚫 забанен" : ""}</div>
          <div class="card-sub">🪙 ${fmt(u.balance)} · 🏢 ${u.businesses} · 🤝 ${u.employees}</div>
          ${u.ban_reason ? `<div class="card-sub">Причина: ${escapeHtml(u.ban_reason)}</div>` : ""}
        </div>
      </div>
      <div class="admin-actions">
        <button class="gold" onclick="adminGrant(${u.id},'balance',1000)">+1000 🪙</button>
        <button class="gold" onclick="adminGrant(${u.id},'everything')">Выдать ВСЁ</button>
        <button onclick="adminGrant(${u.id},'unlock_all')">Открыть всё</button>
        <button onclick="adminReset(${u.id})">Сброс</button>
        ${u.banned
          ? `<button class="ok" onclick="adminUnban(${u.id})">Разбанить</button>`
          : `<button class="danger" onclick="adminBan(${u.id})">Забанить</button>`}
      </div>
    </div>
  `).join("") : `<div class="card muted">Не удалось загрузить список</div>`;

  const total = users ? users.total : 0;
  const canPrev = state.adminOffset > 0;
  const canNext = users ? (state.adminOffset + 10) < total : false;

  container.innerHTML = `
    <div class="view">
      ${tabs}
      <div class="admin-banner">🛠 Админ-панель · игроков: ${fmt(total)}</div>
      ${statsHtml}
      <div class="admin-search">
        <input id="admin-q" placeholder="Поиск: ID или имя" value="${escapeHtml(state.adminQuery)}"
          onkeydown="if(event.key==='Enter')adminSearch()" />
        <button onclick="adminSearch()">🔍</button>
      </div>
      ${listHtml}
      <div class="pagination">
        <button ${canPrev ? "" : "disabled"} onclick="adminPage(-10)">← Назад</button>
        <button ${canNext ? "" : "disabled"} onclick="adminPage(10)">Вперёд →</button>
      </div>
    </div>`;
}

function adminSearch() {
  const el = document.getElementById("admin-q");
  state.adminQuery = el ? el.value.trim() : "";
  state.adminOffset = 0;
  renderAdmin(document.getElementById("view-container"));
}

function adminPage(delta) {
  state.adminOffset = Math.max(0, state.adminOffset + delta);
  renderAdmin(document.getElementById("view-container"));
}

async function adminGrant(userId, kind, amount) {
  const body = { user_id: userId, kind: kind };
  if (typeof amount === "number") body.amount = amount;
  const r = await api("/api/admin/grant", "POST", body);
  toast(r.ok ? "✅ " + r.data.message : "⛔ " + (r.error || "Ошибка"));
  if (r.ok) renderAdmin(document.getElementById("view-container"));
}

async function adminBan(userId) {
  const reason = prompt("Причина бана:", "Нарушение правил") || "";
  const r = await api("/api/admin/ban", "POST", { user_id: userId, reason: reason });
  toast(r.ok ? "🚫 " + r.data.message : "⛔ " + (r.error || "Ошибка"));
  if (r.ok) renderAdmin(document.getElementById("view-container"));
}

async function adminUnban(userId) {
  const r = await api("/api/admin/unban", "POST", { user_id: userId });
  toast(r.ok ? "✅ " + r.data.message : "⛔ " + (r.error || "Ошибка"));
  if (r.ok) renderAdmin(document.getElementById("view-container"));
}

async function adminReset(userId) {
  if (!confirm("Сбросить прогресс игрока " + userId + "?")) return;
  const r = await api("/api/admin/reset", "POST", { user_id: userId });
  toast(r.ok ? "♻️ " + r.data.message : "⛔ " + (r.error || "Ошибка"));
  if (r.ok) renderAdmin(document.getElementById("view-container"));
}

// --- Админ: заявки на донат ------------------------------------------------

async function adminRenderOrders(container, tabs) {
  container.innerHTML = `<div class="view">${tabs}<div class="muted" style="padding:20px;text-align:center">Загрузка…</div></div>`;
  let data = null;
  try {
    const url = `/api/admin/orders?status=${state.ordersStatus}&limit=15&offset=${state.ordersOffset}`;
    const r = await api(url);
    if (r.ok) data = r.data;
  } catch (e) {}

  const filterBar = `
    <div class="admin-tabs small">
      <button class="${state.ordersStatus === '' ? 'active' : ''}" onclick="ordersStatus('')">Все</button>
      <button class="${state.ordersStatus === 'pending' ? 'active' : ''}" onclick="ordersStatus('pending')">⏳ Новые</button>
      <button class="${state.ordersStatus === 'completed' ? 'active' : ''}" onclick="ordersStatus('completed')">✅ Выдано</button>
      <button class="${state.ordersStatus === 'declined' ? 'active' : ''}" onclick="ordersStatus('declined')">❌ Отклонено</button>
    </div>`;

  const listHtml = data && data.orders.length ? data.orders.map(o => `
    <div class="card admin-user">
      <div class="card-info">
        <div class="card-name">#${o.id} · ${escapeHtml(o.service_name)} · ${o.price} ₽</div>
        <div class="card-sub">Покупатель: ${escapeHtml(o.user_name || ("ID " + o.user_id))} (${o.user_id})</div>
        <div class="card-sub">Статус: ${
          o.status === 'pending' ? '⏳ ожидает подтверждения'
          : o.status === 'completed' ? '✅ награда выдана'
          : '❌ отклонена'} · ${new Date(o.created_at * 1000).toLocaleString()}</div>
      </div>
      ${o.status === 'pending' ? `
        <div class="admin-actions">
          <button class="ok" onclick="adminOrderConfirm(${o.id})">💰 Подтвердить оплату</button>
          <button class="danger" onclick="adminOrderDecline(${o.id})">Отклонить</button>
        </div>` : ""}
    </div>
  `).join("") : `<div class="card muted">Заявок нет</div>`;

  const total = data ? data.total : 0;
  container.innerHTML = `
    <div class="view">
      ${tabs}
      <div class="admin-banner">🧾 Заявки на донат · всего: ${fmt(total)}</div>
      ${filterBar}
      ${listHtml}
      <div class="pagination">
        <button ${state.ordersOffset > 0 ? "" : "disabled"} onclick="ordersPage(-15)">←</button>
        <button ${data && (state.ordersOffset + 15) < total ? "" : "disabled"} onclick="ordersPage(15)">→</button>
      </div>
    </div>`;
}

function ordersStatus(s) { state.ordersStatus = s; state.ordersOffset = 0; renderAdmin(document.getElementById("view-container")); }
function ordersPage(d) { state.ordersOffset = Math.max(0, state.ordersOffset + d); renderAdmin(document.getElementById("view-container")); }

async function adminOrderConfirm(orderId) {
  const r = await api("/api/admin/orders/confirm", "POST", { order_id: orderId });
  toast(r.ok ? "✅ " + r.data.message : "⛔ " + (r.error || "Ошибка"));
  if (r.ok) renderAdmin(document.getElementById("view-container"));
}
async function adminOrderDecline(orderId) {
  const r = await api("/api/admin/orders/decline", "POST", { order_id: orderId });
  toast(r.ok ? "❌ " + r.data.message : "⛔ " + (r.error || "Ошибка"));
  if (r.ok) renderAdmin(document.getElementById("view-container"));
}

// --- Админ: рассылка ---------------------------------------------------------

async function adminRenderBroadcast(container, tabs) {
  container.innerHTML = `<div class="view">${tabs}<div class="muted" style="padding:20px;text-align:center">Загрузка…</div></div>`;
  let broadcasts = [];
  try {
    const r = await api("/api/admin/broadcasts");
    if (r.ok) broadcasts = r.data.broadcasts;
  } catch (e) {}

  const sendBox = `
    <div class="card">
      <div class="card-name" style="margin-bottom:8px">📣 Новое сообщение всем игрокам</div>
      <textarea id="bc-text" class="admin-area" rows="4" placeholder="Текст рассылки…"></textarea>
      <button class="btn-primary" onclick="adminBroadcastSend()">📨 Отправить рассылку</button>
    </div>`;

  const listHtml = broadcasts.length ? broadcasts.map(b => `
    <div class="card card-row muted">
      <div class="card-info">
        <div class="card-name">#${b.id} · ${b.status === 'done' ? '✅ завершено' : b.status === 'running' ? '⏳ идёт' : '⏳ в очереди'}</div>
        <div class="card-sub">${escapeHtml(b.text.slice(0, 120))}</div>
        <div class="card-sub">Отправлено: <b>${b.sent}</b> · Ошибок: ${b.failed} · Всего игроков: ${b.total || "—"}</div>
      </div>
    </div>`).join("") : `<div class="card muted">Рассылок пока не было</div>`;

  container.innerHTML = `
    <div class="view">
      ${tabs}
      <div class="admin-banner">📣 Рассылка по всем игрокам</div>
      ${sendBox}
      <div class="section-title">История рассылок</div>
      ${listHtml}
    </div>`;
}

async function adminBroadcastSend() {
  const el = document.getElementById("bc-text");
  const text = el ? el.value.trim() : "";
  if (!text) { toast("Введи текст рассылки"); return; }
  const r = await api("/api/admin/broadcast", "POST", { text: text });
  toast(r.ok ? "✅ " + r.data.message : "⛔ " + (r.error || "Ошибка"));
  if (r.ok) renderAdmin(document.getElementById("view-container"));
}

// Запуск
boot();