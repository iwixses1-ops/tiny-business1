# -*- coding: utf-8 -*-
"""
Административные функции Tiny Business.

Доступны только пользователям из ADMIN_IDS. Через них админ может:
  - искать игроков и смотреть их состояние;
  - выдавать монеты, открывать предприятия, нанимать сотрудников, включать
    достижения («выдать всё»);
  - банить и разбанивать игроков;
  - сбрасывать прогресс;
  - смотреть общую статистику.

Все операции — на сервере, с проверкой прав на стороне API (см. main.py).
"""

from __future__ import annotations

import time

from backend import economy as eco
from backend import game as game_logic
from backend.config import config
from backend.database import Database


# --- Права -------------------------------------------------------------------


def is_admin(user_id: int | None) -> bool:
    """Является ли пользователь администратором (по ADMIN_IDS)."""
    return config.is_admin(user_id)


# --- Бан ---------------------------------------------------------------------


def is_banned(db: Database, user_id: int) -> bool:
    """Забанен ли игрок."""
    row = db._query_one("SELECT banned FROM users WHERE id = ?", (user_id,))
    return bool(row and row["banned"])


def ban(db: Database, user_id: int, reason: str = "") -> dict:
    """Блокирует игрока. Админа забанить нельзя."""
    if is_admin(user_id):
        return {"success": False, "message": "Нельзя забанить администратора"}
    with db.transaction() as con:
        row = con.execute("SELECT id FROM users WHERE id = ?", (user_id,)).fetchone()
        if not row:
            return {"success": False, "message": "Игрок не найден"}
        con.execute(
            "UPDATE users SET banned = 1, ban_reason = ? WHERE id = ?",
            (reason or "Нарушение правил", user_id),
        )
        return {"success": True, "message": "Игрок забанен"}


def unban(db: Database, user_id: int) -> dict:
    """Снимает бан."""
    with db.transaction() as con:
        row = con.execute("SELECT id FROM users WHERE id = ?", (user_id,)).fetchone()
        if not row:
            return {"success": False, "message": "Игрок не найден"}
        con.execute(
            "UPDATE users SET banned = 0, ban_reason = '' WHERE id = ?", (user_id,)
        )
        return {"success": True, "message": "Игрок разбанен"}


# --- Список и статистика -----------------------------------------------------


def list_users(db: Database, query: str = "", limit: int = 20, offset: int = 0) -> dict:
    """Поиск игроков по ID или имени. Возвращает список и общее число."""
    limit = max(1, min(limit, 50))
    offset = max(0, offset)
    q = (query or "").strip()

    if q.isdigit():
        where = "WHERE u.id = ?"
        params: tuple = (int(q),)
    elif q:
        where = "WHERE u.name LIKE ?"
        params = (f"%{q}%",)
    else:
        where = ""
        params = ()

    total_row = db._query_one(
        f"SELECT COUNT(*) AS c FROM users u {where}", params
    )
    total = total_row["c"] if total_row else 0

    rows = db._query_all(
        f"SELECT u.id, u.name, u.banned, u.ban_reason, u.created_at, "
        f"       COALESCE(b.balance, 0) AS balance, "
        f"       COALESCE(b.total_earned, 0) AS total_earned, "
        f"       (SELECT COUNT(*) FROM businesses bx WHERE bx.user_id = u.id AND bx.level > 0) AS businesses, "
        f"       (SELECT COUNT(*) FROM employees ex WHERE ex.user_id = u.id AND ex.count > 0) AS employees "
        f"FROM users u LEFT JOIN balances b ON b.user_id = u.id "
        f"{where} "
        f"ORDER BY u.last_active DESC, u.id ASC "
        f"LIMIT ? OFFSET ?",
        params + (limit, offset),
    )

    users = [
        {
            "id": r["id"],
            "name": r["name"],
            "balance": r["balance"],
            "total_earned": r["total_earned"],
            "businesses": r["businesses"],
            "employees": r["employees"],
            "banned": bool(r["banned"]),
            "ban_reason": r["ban_reason"] or "",
            "created_at": r["created_at"],
            "is_admin": is_admin(r["id"]),
        }
        for r in rows
    ]
    return {"users": users, "total": total, "limit": limit, "offset": offset}


def stats(db: Database) -> dict:
    """Общая статистика по игре."""
    users = db._query_one("SELECT COUNT(*) AS c FROM users")
    banned = db._query_one("SELECT COUNT(*) AS c FROM users WHERE banned = 1")
    totals = db._query_one(
        "SELECT COALESCE(SUM(balance),0) AS bal, COALESCE(SUM(total_earned),0) AS earned "
        "FROM balances"
    )
    businesses = db._query_one(
        "SELECT COUNT(*) AS c FROM businesses WHERE level > 0"
    )
    return {
        "users": users["c"] if users else 0,
        "banned": banned["c"] if banned else 0,
        "total_balance": totals["bal"] if totals else 0,
        "total_earned": totals["earned"] if totals else 0,
        "businesses": businesses["c"] if businesses else 0,
        "admins": len(config.ADMIN_IDS),
    }


# --- Выдача ресурсов ---------------------------------------------------------


def grant(
    db: Database,
    user_id: int,
    kind: str,
    amount: int = 0,
    business_id: str | None = None,
    level: int | None = None,
    employee_id: str | None = None,
) -> dict:
    """
    Выдаёт игроку ресурсы. Виды (kind):
      - "balance"     — добавить amount монет
      - "set_balance" — установить баланс = amount
      - "business"    — установить business_id на уровень level
      - "employee"    — выдать сотрудника employee_id
      - "unlock_all"  — открыть ВСЕ предприятия (уровень level, по умолч. 10)
                        и нанять ВСЕХ сотрудников
      - "everything"  — unlock_all + 1 000 000 монет
    """
    # Игрок должен существовать (создаём при необходимости)
    game_logic.ensure_player(db, user_id, f"Игрок {user_id}")

    with db.transaction() as con:
        def _add_coins(delta: int) -> None:
            con.execute(
                "UPDATE balances SET balance = balance + ?, total_earned = total_earned + ? "
                "WHERE user_id = ?",
                (delta, max(0, delta), user_id),
            )

        def _set_business(bid: str, lvl: int) -> None:
            con.execute(
                "INSERT INTO businesses (user_id, business_id, level, bought_at) "
                "VALUES (?, ?, ?, ?) "
                "ON CONFLICT(user_id, business_id) DO UPDATE SET level = excluded.level",
                (user_id, bid, lvl, int(time.time())),
            )

        def _add_employee(eid: str) -> None:
            con.execute(
                "UPDATE employees SET count = 1 WHERE user_id = ? AND employee_id = ?",
                (user_id, eid),
            )

        if kind == "balance":
            if amount == 0:
                return {"success": False, "message": "Укажи сумму"}
            _add_coins(amount)
            msg = f"Начислено {amount} монет"

        elif kind == "set_balance":
            con.execute(
                "UPDATE balances SET balance = ? WHERE user_id = ?", (amount, user_id)
            )
            msg = f"Баланс установлен: {amount}"

        elif kind == "business":
            if not business_id or not eco.validate_business_id(business_id):
                return {"success": False, "message": "Неизвестное предприятие"}
            lvl = max(1, min(level or 1, eco.MAX_BUSINESS_LEVEL))
            _set_business(business_id, lvl)
            msg = f"{eco.BUSINESSES[business_id].name} → уровень {lvl}"

        elif kind == "employee":
            if not employee_id or not eco.validate_employee_id(employee_id):
                return {"success": False, "message": "Неизвестный сотрудник"}
            _add_employee(employee_id)
            msg = f"{eco.EMPLOYEES[employee_id].name} нанят"

        elif kind == "unlock_all":
            lvl = max(1, min(level or 10, eco.MAX_BUSINESS_LEVEL))
            for biz in eco.BUSINESSES:
                _set_business(biz, lvl)
            for emp in eco.EMPLOYEES:
                _add_employee(emp)
            msg = f"Открыты все предприятия (ур.{lvl}) и сотрудники"

        elif kind == "everything":
            lvl = max(1, min(level or 10, eco.MAX_BUSINESS_LEVEL))
            for biz in eco.BUSINESSES:
                _set_business(biz, lvl)
            for emp in eco.EMPLOYEES:
                _add_employee(emp)
            _add_coins(1_000_000)
            msg = "Выдано ВСЁ: предприятия, сотрудники, 1 000 000 монет"

        else:
            return {"success": False, "message": f"Неизвестный тип выдачи: {kind}"}

        # Автоматически открываем достижения, чтобы состояние было консистентным
    game_logic.update_achievements(db, user_id)
    return {"success": True, "message": msg}


# --- Сброс прогресса ---------------------------------------------------------


def reset_progress(db: Database, user_id: int) -> dict:
    """Полностью сбрасывает прогресс игрока до стартового состояния."""
    if is_admin(user_id):
        return {"success": False, "message": "Нельзя сбросить админа"}
    with db.transaction() as con:
        row = con.execute("SELECT id FROM users WHERE id = ?", (user_id,)).fetchone()
        if not row:
            return {"success": False, "message": "Игрок не найден"}

        con.execute(
            "DELETE FROM businesses WHERE user_id = ?", (user_id,)
        )
        con.execute("DELETE FROM employees WHERE user_id = ?", (user_id,))
        con.execute("DELETE FROM achievements_status WHERE user_id = ?", (user_id,))
        con.execute("DELETE FROM tasks_status WHERE user_id = ?", (user_id,))
        con.execute("DELETE FROM operation_log WHERE user_id = ?", (user_id,))

        # Восстанавливаем стартовое состояние
        con.execute(
            "UPDATE balances SET balance = ?, total_earned = 0, last_income_at = ? "
            "WHERE user_id = ?",
            (eco.START_BALANCE, int(time.time()), user_id),
        )
        # Снимаем премиум (иначе он остался бы «подарком» после сброса)
        con.execute("UPDATE users SET premium_until = 0 WHERE id = ?", (user_id,))
        con.execute(
            "INSERT OR IGNORE INTO businesses (user_id, business_id, level, bought_at) "
            "VALUES (?, ?, 1, ?)",
            (user_id, eco.STARTUP_BUSINESS_ID, int(time.time())),
        )
        for emp in eco.EMPLOYEES:
            con.execute(
                "INSERT OR IGNORE INTO employees (user_id, employee_id, count) VALUES (?, ?, 0)",
                (user_id, emp),
            )
        return {"success": True, "message": "Прогресс сброшен"}
