# -*- coding: utf-8 -*-
"""
Единый источник игровой экономики Tiny Business.

Все цены, доходы и настройки баланса собраны ЗДЕСЬ, чтобы их было
легко менять в одном месте без правки логики в других файлах.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

# ---------------------------------------------------------------------------
# Стартовые параметры нового игрока
# ---------------------------------------------------------------------------

START_BALANCE = 100      # начальный баланс
START_MONEY_PER_MIN = 2  # базовый доход от лимонада в минуту

# Палатка с лимонадом выдаётся бесплатно при старте
STARTUP_BUSINESS_ID = "lemonade_stand"

# ---------------------------------------------------------------------------
# Описание предприятий: base_cost — цена открытия, base_income — доход в минуту
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Business:
    """Статические параметры одного предприятия (не меняются игроком)."""

    id: str
    name: str
    emoji: str
    base_cost: int          # стоимость открытия
    base_income: int        # базовый доход в минуту
    description: str


BUSINESSES: dict[str, Business] = {
    "lemonade_stand": Business(
        id="lemonade_stand",
        name="Палатка с лимонадом",
        emoji="🥤",
        base_cost=0,
        base_income=2,
        description="Точка с холодным лимонадом на углу улицы.",
    ),
    "grocery_store": Business(
        id="grocery_store",
        name="Продуктовый магазин",
        emoji="🏪",
        base_cost=300,
        base_income=12,
        description="Небольшой магазинчик с продуктами.",
    ),
    "cafe": Business(
        id="cafe",
        name="Кафе",
        emoji="☕",
        base_cost=1000,
        base_income=35,
        description="Уютное место для кофе и десертов.",
    ),
    "pizzeria": Business(
        id="pizzeria",
        name="Пиццерия",
        emoji="🍕",
        base_cost=5000,
        base_income=120,
        description="Горячая пицца прямо из печи.",
    ),
    "supermarket": Business(
        id="supermarket",
        name="Супермаркет",
        emoji="🛒",
        base_cost=20000,
        base_income=400,
        description="Огромный магазин со всем необходимым.",
    ),
    "hotel": Business(
        id="hotel",
        name="Отель",
        emoji="🏨",
        base_cost=100000,
        base_income=1800,
        description="Комфорт и сервис для гостей города.",
    ),
}


# Параметры улучшений -------------------------------------------------------
UPGRADE_COST_MULTIPLIER = 1.7   # стоимость следующего уровня ≈ ×1.7
UPGRADE_INCOME_MULTIPLIER = 1.6  # доход уровня N ≈ базовый × 1.6^(N)

MAX_BUSINESS_LEVEL = 50         # верхний предел уровня бизнеса

# Множитель дохода при активном премиуме (×1.5)
PREMIUM_INCOME_MULTIPLIER = 1.5


def business_cost(biz: Business, level: int) -> int:
    """Стоимость ПЕРВОГО покупки (level == 0) или следующего уровня.

    Действует принцип: первый уровень (открытие) стоит base_cost,
    каждый следующий уровень умножается на ~1.7.
    """
    base = biz.base_cost
    if level <= 0:
        return base
    cost = base * (UPGRADE_COST_MULTIPLIER ** level)
    return int(math.ceil(cost))


def business_income(biz: Business, level: int) -> int:
    """Доход в минуту предприятия на заданном уровне."""
    if level <= 0:
        return 0
    value = biz.base_income * (UPGRADE_INCOME_MULTIPLIER ** (level - 1))
    return int(round(value))


# ---------------------------------------------------------------------------
# Сотрудники
# ---------------------------------------------------------------------------

# employee_id -> (название, цена, тип бонуса)
# Типы бонусов обрабатываются в game.py:
#   "global_mult": множитель ко всему доходу (percentage — проценты)
#   "business_mult": множитель к доходу конкретного предприятия


@dataclass(frozen=True)
class Employee:
    id: str
    name: str
    emoji: str
    cost: int
    bonus_kind: str          # global_mult | business_mult
    percentage: int          # размер бонуса в процентах
    target_business: str | None = None  # для business_mult


EMPLOYEES: dict[str, Employee] = {
    "seller": Employee(
        id="seller",
        name="Продавец",
        emoji="🧑‍🍳",
        cost=200,
        bonus_kind="business_mult",
        percentage=10,
        target_business="lemonade_stand",
    ),
    "cook": Employee(
        id="cook",
        name="Повар",
        emoji="👨‍🍳",
        cost=1000,
        bonus_kind="business_mult",
        percentage=15,
        target_business="cafe",
    ),
    "manager": Employee(
        id="manager",
        name="Менеджер",
        emoji="👔",
        cost=5000,
        bonus_kind="global_mult",
        percentage=10,
    ),
    "director": Employee(
        id="director",
        name="Директор",
        emoji="🎩",
        cost=25000,
        bonus_kind="global_mult",
        percentage=15,
    ),
}

# ---------------------------------------------------------------------------
# Ежедневные задания (обновляются по календарному дню в UTC)
# ---------------------------------------------------------------------------

TASKS_PER_DAY = 3  # сколько заданий максимум предлагается в день


@dataclass(frozen=True)
class DailyTask:
    task_id: str        # уникальный идентификатор задания (для каждой карточки)
    emoji: str
    title: str
    description: str
    reward: int         # награда в монетах за выполнение


# Задания, из которых ежедневно выбираются активные
AVAILABLE_TASKS: list[DailyTask] = [
    DailyTask("login", "🚀", "Зайти в игру",
              "Просто запусти игру сегодня.", 25),
    DailyTask("collect_50", "💰", "Собрать 50 монет",
              "Доход от бизнеса должен принести 50 монет за сегодня.", 30),
    DailyTask("collect_200", "🏦", "Собрать 200 монет",
              "Заработай 200 монет доходом за сегодня.", 50),
    DailyTask("buy_upgrade", "⬆️", "Купить улучшение",
              "Улучши любое предприятие.", 40),
    DailyTask("open_business", "🏪", "Открыть предприятие",
              "Открой новое предприятие.", 60),
    DailyTask("hire_employee", "🤝", "Нанять сотрудника",
              "Нанми себе помощника.", 40),
    DailyTask("total_collect_1000", "💎", "Собрать 1000 всего",
              "Суммарно заработай 1000 монет.", 75),
]

# Количество заданий, выбираемых каждый день (первые TASKS_PER_DAY)
# Задания выбираются по порядку из списка; для разнообразия в будущем
# можно перемешивать по seed дня.

# ---------------------------------------------------------------------------
# Достижения (выдаются один раз навсегда)
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Achievement:
    ach_id: str
    emoji: str
    title: str
    description: str
    reward: int


ACHIEVEMENTS: list[Achievement] = [
    Achievement("first_business", "🏪", "Первый бизнес",
                "Открой своё первое предприятие.", 100),
    Achievement("first_upgrade", "⬆️", "Первое улучшение",
                "Улучши любое предприятие до уровня 2.", 150),
    Achievement("first_1000", "💰", "Первые 1000 монет",
                "Накопи баланс в 1000 монет (в сумме заработанных).", 200),
    Achievement("three_businesses", "🏪", "Три предприятия",
                "Открой три предприятия.", 300),
    Achievement("first_employee", "🤝", "Первый сотрудник",
                "Найми первого сотрудника.", 150),
    Achievement("ten_upgrades", "🚀", "10 улучшений",
                "Соверши суммарно 10 улучшений бизнеса.", 500),
]

# ---------------------------------------------------------------------------
# Профиль для рейтинга
# ---------------------------------------------------------------------------

LEADERBOARD_SIZE = 10  # сколько игроков показывается в топе

# ---------------------------------------------------------------------------
# Вспомогательные функции
# ---------------------------------------------------------------------------


def businesses_ordered() -> list[Business]:
    """Список предприятий в порядке их открытия (по цене)."""
    return sorted(BUSINESSES.values(), key=lambda b: b.base_cost)


def initial_businesses() -> dict[str, int]:
    """Стартовый набор предприятий: лимонад на 1 уровне или куплен."""
    return {STARTUP_BUSINESS_ID: 1}


def validate_business_id(business_id: str) -> bool:
    return business_id in BUSINESSES


def validate_employee_id(employee_id: str) -> bool:
    return employee_id in EMPLOYEES