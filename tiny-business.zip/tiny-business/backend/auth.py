# -*- coding: utf-8 -*-
"""
Проверка подлинности Telegram Mini App initData.

Реализовано по официальной документации Telegram:
https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app

 initData = "query_id=...&user=...&auth_date=...&hash=..."
 Верификация: HMAC-SHA256 с ключом HMAC_SHA256("WebAppData", bot_token).
"""
from __future__ import annotations

import hashlib
import hmac
import json
import time
import urllib.parse

from backend.config import config

_OFFICIAL_KEY = b"WebAppData"


def _token_key() -> bytes:
    """Строит secret_key = HMAC_SHA256(b'WebAppData', bytes(bot_token))."""
    return hmac.new(_OFFICIAL_KEY, config.BOT_TOKEN.encode("utf-8"), hashlib.sha256).digest()


def verify_telegram_hash(data: dict[str, str]) -> bool:
    """
    Проверяет подпись `hash` для переданных данных initData.
    Передаваемый dict — уже распарсенные поля (без hash в основном списке).
    """
    received_hash = data.get("hash")
    if not received_hash:
        return False

    # Все поля, КРОМЕ hash, сортируем и склеиваем как key=value\n...
    check_items = sorted(
        (k, v) for k, v in data.items() if k != "hash"
    )
    data_check_string = "\n".join(f"{k}={v}" for k, v in check_items)

    secret_key = _token_key()
    computed = hmac.new(secret_key, data_check_string.encode("utf-8"), hashlib.sha256).hexdigest()

    # Постоянный по времени сравнение
    return hmac.compare_digest(computed, received_hash)


def parse_init_data(init_data: str) -> dict[str, str]:
    """Преобразует raw initData в dict строковых полей."""
    parsed = urllib.parse.parse_qs(init_data)
    return {k: v[0] for k, v in parsed.items()}


def extract_user(payload: dict[str, str]) -> dict | None:
    """Извлекает и парсит поле user (JSON) из initData."""
    raw_user = payload.get("user")
    if not raw_user:
        return None
    try:
        user = json.loads(raw_user)
    except (ValueError, TypeError):
        return None
    if not isinstance(user, dict):
        return None
    return user


def validate_init_data(init_data: str) -> tuple[int, str] | None:
    """
    Проверяет initData и возвращает (user_id, имя) или None при ошибке.

    Если включён локальный тестовый режим (ALLOW_LOCAL_TEST=True) и
    initData отсутствует — возвращает синтетического пользователя.
    """
    if not init_data:
        if config.auth_required:
            return None
        return _local_user()

    payload = parse_init_data(init_data)

    if not verify_telegram_hash(payload):
        return None

    auth_date = payload.get("auth_date")
    if not auth_date:
        return None
    try:
        auth_ts = int(auth_date)
    except (ValueError, TypeError):
        return None

    # Свежесть данных
    now = int(time.time())
    if now - auth_ts > config.AUTH_MAX_AGE_SECONDS or auth_ts > now + 60:
        return None

    user = extract_user(payload)
    if not user:
        return None

    user_id = user.get("id")
    if not isinstance(user_id, int) and not str(user_id).isdigit():
        return None
    user_id = int(user_id)

    first_name = user.get("first_name", "") or ""
    last_name = user.get("last_name", "") or ""
    username = user.get("username")
    display = (first_name + " " + last_name).strip() or (username or "Игрок")
    return user_id, display.strip()


def _local_user() -> tuple[int, str]:
    """
    Синтетический пользователь для локальной разработки (не в публике).

    Возвращает СТАБИЛЬНЫЙ id, чтобы прогресс сохранялся между запросами
    в браузерном dev-режиме (нет Telegram-личности). Используется только
    когда ALLOW_LOCAL_TEST=True и PUBLIC_DEPLOYMENT=False.
    """
    return 1000000, "Локальный тест"


def make_test_init_data(user_id: int, first_name: str = "Тест") -> str:
    """
    Создаёт ВАЛИДНУЮ подпись для тестов (и отладки).

    Только для pytest/локальной разработки, НИКОГДА не вызывать в проде.
    """
    auth_date = str(int(time.time()))
    user = json.dumps(
        {
            "id": user_id,
            "first_name": first_name,
            "username": f"user{user_id}",
            "language_code": "ru",
        },
        ensure_ascii=False,
    )
    check = {"user": user, "auth_date": auth_date}
    data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(check.items()))
    secret = _token_key()
    h = hmac.new(secret, data_check_string.encode("utf-8"), hashlib.sha256).hexdigest()
    params = urllib.parse.urlencode({"user": user, "auth_date": auth_date, "hash": h})
    return params