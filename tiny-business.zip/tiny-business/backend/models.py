# -*- coding: utf-8 -*-
"""
Pydantic-модели запросов/ответов API.

Служат валидацией входящих данных и формированием понятных ответов.
Клиент никогда напрямую не управляет балансом/уровнями — здесь только
идентификаторы и (в ответах) вычисленные сервером значения.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


# --- Наружные ответы ------------------------------------------------------


class UserOut(BaseModel):
    id: int
    name: str
    first_name: str = ""
    username: str | None = None
    created_at: int
    last_active: int


class BalanceOut(BaseModel):
    balance: int
    total_earned: int


class BusinessOut(BaseModel):
    business_id: str
    name: str
    emoji: str
    level: int
    owned: bool
    base_cost: int
    base_income: int
    next_cost: int
    income: int          # текущий доход в минуту (с учётом уровня, без бонусов сотрудников)
    description: str


class EmployeeOut(BaseModel):
    employee_id: str
    name: str
    emoji: str
    cost: int
    count: int
    bonus_kind: str
    percentage: int
    bonus_description: str


class MeOut(BaseModel):
    user: UserOut
    balance: int
    total_earned: int
    money_per_min: int
    offline_pending: int
    offline_seconds: int
    businesses: list[BusinessOut]
    employees: list[EmployeeOut]


class TaskOut(BaseModel):
    key: str
    emoji: str
    title: str
    description: str
    reward: int
    progress: int = 0
    target: int = 1
    done: bool
    claimed: bool


class AchievementOut(BaseModel):
    ach_id: str
    emoji: str
    title: str
    description: str
    reward: int
    done: bool
    claimed: bool


class LeaderboardRow(BaseModel):
    position: int
    name: str
    balance: int


class LeaderboardOut(BaseModel):
    rows: list[LeaderboardRow]
    player: LeaderboardRow | None = None


class ReferralOut(BaseModel):
    referral_link: str
    invited_count: int
    reward: int
    can_get_more: bool


class OperationResult(BaseModel):
    success: bool
    message: str
    balance: int
    # Опциональные обновления (задания/достижения/офлайн)
    granted_achievements: list[AchievementOut] = Field(default_factory=list)
    tasks: list[TaskOut] = Field(default_factory=list)


# --- Внутренние структуры --------------------------------------------------


class BusinessBuyResult(BaseModel):
    success: bool
    message: str
    balance: int = 0


# --- Админ-запросы ---------------------------------------------------------


class AdminGrantIn(BaseModel):
    """Выдача ресурсов игроку (админ)."""

    user_id: int
    kind: str = Field(
        description="balance | set_balance | business | employee | unlock_all | everything"
    )
    amount: int = 0
    business_id: str | None = None
    level: int | None = None
    employee_id: str | None = None


class AdminBanIn(BaseModel):
    """Бан игрока (админ)."""

    user_id: int
    reason: str = ""


class AdminUserIn(BaseModel):
    """Операция над одним игроком (админ): разбан/сброс."""

    user_id: int


# --- Магазин / рассылка -----------------------------------------------------


class ShopOrderIn(BaseModel):
    """Создание донат-заявки."""

    service_id: str


class AdminOrderIn(BaseModel):
    """Подтверждение/отклонение заявки админом."""

    order_id: int


class BroadcastIn(BaseModel):
    """Создание рассылки админом."""

    text: str = Field(min_length=1, max_length=4000)