# -*- coding: utf-8 -*-
"""
Очередь рассылок для администраторов.

Создание рассылки кладёт её в таблицу broadcasts. Обработка отправки —
фоновым воркером в боте (bot/main.py), чтобы не блокировать запросы.
Здесь — только работа с очередью: создание, статистика, получение «кампаний
в работе», отметка отправки конкретному игроку.
"""

from __future__ import annotations

import time

from backend.config import config
from backend.database import Database


def broadcast_create(db: Database, admin_id: int, text: str) -> dict:
    """Создаёт рассылку в очереди. Возвращает её данные."""
    text = text.strip()
    if not text:
        return {"success": False, "message": "Пустое сообщение"}
    now = int(time.time())
    with db.transaction() as con:
        cur = con.execute(
            "INSERT INTO broadcasts (admin_id, text, status, created_at) VALUES (?, ?, 'pending', ?)",
            (admin_id, text, now),
        )
        broadcast_id = cur.lastrowid
    return {
        "success": True,
        "message": f"Рассылка #{broadcast_id} поставлена в очередь",
        "broadcast_id": broadcast_id,
    }


def broadcast_list(db: Database) -> list[dict]:
    """Последние рассылки со статусом."""
    rows = db._query_all(
        "SELECT * FROM broadcasts ORDER BY created_at DESC LIMIT 20"
    )
    return [dict(r) for r in rows]


def get_pending_broadcast(db: Database) -> dict | None:
    """Возвращает одну рассылку, ещё не обработанную (для воркера)."""
    row = db._query_one(
        "SELECT * FROM broadcasts WHERE status IN ('pending','running') "
        "ORDER BY created_at ASC LIMIT 1"
    )
    return dict(row) if row else None


def mark_broadcast_running(db: Database, broadcast_id: int) -> None:
    with db.transaction() as con:
        con.execute(
            "UPDATE broadcasts SET status = 'running', started_at = ? WHERE id = ?",
            (int(time.time()), broadcast_id),
        )


def mark_broadcast_done(db: Database, broadcast_id: int) -> None:
    with db.transaction() as con:
        con.execute(
            "UPDATE broadcasts SET status = 'done', finished_at = ? WHERE id = ?",
            (int(time.time()), broadcast_id),
        )


def finish_broadcast(db: Database, broadcast_id: int, failed: int) -> None:
    """Завершает рассылку: ставит статус done и считает отправленных."""
    with db.transaction() as con:
        sent = con.execute(
            "SELECT COUNT(*) AS c FROM broadcast_recipients WHERE broadcast_id = ?",
            (broadcast_id,),
        ).fetchone()["c"]
        con.execute(
            "UPDATE broadcasts SET sent = ?, failed = ?, status = 'done', finished_at = ? "
            "WHERE id = ?",
            (sent, failed, int(time.time()), broadcast_id),
        )


def add_broadcast_recipient(db: Database, broadcast_id: int, user_id: int) -> None:
    """Помечает игрока как уже получившего сообщение (идемпотентно)."""
    with db.transaction() as con:
        con.execute(
            "INSERT OR IGNORE INTO broadcast_recipients (broadcast_id, user_id) VALUES (?, ?)",
            (broadcast_id, user_id),
        )


def already_sent(db: Database, broadcast_id: int, user_id: int) -> bool:
    row = db._query_one(
        "SELECT 1 FROM broadcast_recipients WHERE broadcast_id = ? AND user_id = ?",
        (broadcast_id, user_id),
    )
    return row is not None


def broadcast_targets(db: Database, broadcast_id: int) -> list[int]:
    """
    Список Telegram ID игроков для рассылки.

    Защита: «кому уже отправили» хранится в broadcast_recipients, поэтому
    при повторных обработках (например после рестарта) дублей не будет —
    воркер пропускает тех, кто уже в этом списке.
    """
    rows = db._query_all("SELECT id FROM users")
    return [r["id"] for r in rows]


def rate_limited() -> float:
    """
    Пауза между сообщениями рассылки (сек).

    Учитываем ОБА ограничения из конфига: явную задержку
    BROADCAST_DELAY_SEC и максимальную скорость BROADCAST_RATE_PER_MIN
    (60 / N секунд на сообщение) — чтобы не ловить лимиты Telegram.
    """
    per_minute = max(1, config.BROADCAST_RATE_PER_MIN)
    delay_by_rate = 60.0 / per_minute
    return max(0.1, config.BROADCAST_DELAY_SEC, delay_by_rate)