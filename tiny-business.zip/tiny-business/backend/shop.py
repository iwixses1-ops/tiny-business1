# -*- coding: utf-8 -*-
"""
Донат-магазин Tiny Business.

Продаются ОПЦИОНАЛЬНЫЕ цифровые товары для игры (монеты и премиум-время):
  • монеты — внутриигровая валюта;
  • премиум — временный множитель дохода (геймплейный бонус).

Никакого казино, ставок, случайных выигрышей и вывода игровых монет в
реальные деньги здесь нет. Покупка не обязательна для прохождения.

Поток (всё автоматически):
  1) Клиент в Mini App нажимает «Купить» → создаётся заявка (orders).
  2) Заявка появляется в админ-панели со статусом "new".
  3) Клиент видит ссылку на владельца (t.me/...) и оплачивает ему напрямую.
  4) Владелец в админ-панели нажимает «Подтвердить» → награда выдаётся
     автоматически (монеты начисляются / премиум включается).

Прав доступа у сервера: любой может создать заявку, подтверждать/выдавать —
только админ.
"""

from __future__ import annotations

import time
from dataclasses import dataclass

from backend import game as game_logic
from backend.config import config
from backend.database import Database

# Виды награды за услугу
KIND_COINS = "coins"     # + amount монет
KIND_PREMIUM = "premium"  # + amount дней премиума (x1.5 к доходу)


@dataclass(frozen=True)
class Service:
    """Статическое описание платной услуги."""

    id: str
    name: str
    emoji: str
    description: str   # подробное описание для Mini App
    price: int         # цена в рублях (оплата владельцу напрямую)
    kind: str          # KIND_COINS | KIND_PREMIUM
    amount: int        # монет или дней
    badge: str = ""    # метка "Хит" и т.п.


# --- Каталог услуг -------------------------------------------------------------

SERVICES: dict[str, Service] = {
    # Монеты (донат, некритично)
    "coins_small": Service(
        id="coins_small",
        name="🪙 Стартовый пакет монет",
        emoji="🪙",
        description=(
            "50 000 монет для быстрого старта и развития.\n"
            "Подойдёт, чтобы открыть кафе и пиццерию и начать"
            "фармить доход в разы быстрее."
        ),
        price=25,
        kind=KIND_COINS,
        amount=50_000,
        badge="Быстрый старт",
    ),
    "coins_medium": Service(
        id="coins_medium",
        name="💼 Бизнес-пакет",
        emoji="💼",
        description=(
            "250 000 монет. Позволит открыть супермаркет и нанять"
            "менеджера и директора для серьёзного пассивного дохода."
        ),
        price=60,
        kind=KIND_COINS,
        amount=250_000,
        badge="Популярный",
    ),
    "coins_big": Service(
        id="coins_big",
        name="💰 Казна империи",
        emoji="💰",
        description=(
            "1 000 000 монет. Максимум для строительства всей империи:"
            "отель, все улучшения и сотрудники. Играй на полную."
        ),
        price=150,
        kind=KIND_COINS,
        amount=1_000_000,
        badge="Максимум",
    ),

    # Премиум (множитель дохода)
    "premium_1": Service(
        id="premium_1",
        name="⭐ Премиум на 1 день",
        emoji="⭐",
        description=(
            "Доход предприятия увеличивается в 1,5 раза на 1 день.\n"
            "Действует и на офлайн-доход. Идеально для теста."
        ),
        price=35,
        kind=KIND_PREMIUM,
        amount=1,
    ),
    "premium_7": Service(
        id="premium_7",
        name="🌟 Премиум на 7 дней",
        emoji="🌟",
        description=(
            "Доход x1.5 в течение 7 дней (включая офлайн).\n"
            "Лучший баланс цены и выгоды для активных игроков."
        ),
        price=120,
        kind=KIND_PREMIUM,
        amount=7,
        badge="Выгодно",
    ),
    "premium_30": Service(
        id="premium_30",
        name="👑 Премиум на 30 дней",
        emoji="👑",
        description=(
            "Месяц с доходом x1.5. Максимально ускоряет продвижение.\n"
            "Самый выгодный тариф и приятный статус в профиле."
        ),
        price=250,
        kind=KIND_PREMIUM,
        amount=30,
        badge="Лучшая цена",
    ),
}


def list_services() -> list[dict]:
    """Каталог услуг, упорядоченных по цене."""
    items = sorted(SERVICES.values(), key=lambda s: s.price)
    return [
        {
            "id": s.id,
            "name": s.name,
            "emoji": s.emoji,
            "description": s.description,
            "price": s.price,
            "kind": s.kind,
            "amount": s.amount,
            "badge": s.badge,
        }
        for s in items
    ]


def get_service(service_id: str) -> Service | None:
    return SERVICES.get(service_id)


# --- Заявки -------------------------------------------------------------------


def create_order(db: Database, user_id: int, service_id: str) -> dict:
    """
    Создаёт заявку на покупку. Возвращает данные заявки и ссылку на
    владельца для оплаты. Награда НЕ выдаётся до подтверждения админом.
    """
    service = get_service(service_id)
    if not service:
        return {"success": False, "message": "Услуга не найдена"}
    if not config.owner_link():
        return {"success": False, "message": "Оплата временно недоступна"}

    game_logic.ensure_player(db, user_id, f"Игрок {user_id}")
    now = int(time.time())
    with db.transaction() as con:
        # Ограничение: не больше 5 незакрытых заявок у одного игрока
        pending = con.execute(
            "SELECT COUNT(*) AS c FROM orders "
            "WHERE user_id = ? AND status IN ('pending')",
            (user_id,),
        ).fetchone()["c"]
        if pending >= 5:
            return {
                "success": False,
                "message": "Слишком много неоплаченных заявок. Дождись завершения.",
            }

        cur = con.execute(
            "INSERT INTO orders (user_id, service_id, service_name, price, status, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, 'pending', ?, ?)",
            (user_id, service.id, service.name, service.price, now, now),
        )
        order_id = cur.lastrowid

    return {
        "success": True,
        "order": _order_dict(con, order_id),
        "owner_link": config.owner_link(),
        "pay_instruction": (
            f"1. Нажми «Оплатить у владельца».\n"
            f"2. Напиши владельцу номер заявки #{order_id} и оплати.\n"
            f"3. После подтверждения товар зачислится автоматически."
        ),
    }


def _order_dict(con, order_id: int) -> dict:
    r = con.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
    return {
        "id": r["id"],
        "user_id": r["user_id"],
        "service_id": r["service_id"],
        "service_name": r["service_name"],
        "price": r["price"],
        "status": r["status"],
        "created_at": r["created_at"],
    }


def list_user_orders(db: Database, user_id: int, limit: int = 10) -> list[dict]:
    rows = db._query_all(
        "SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT ?",
        (user_id, limit),
    )
    return [dict(r) for r in rows]


def admin_list_orders(
    db: Database,
    status: str | None = None,
    limit: int = 20,
    offset: int = 0,
) -> dict:
    """Список заявок для админ-панели (со статусом)."""
    limit = max(1, min(limit, 50))
    offset = max(0, offset)

    where = ""
    params: list = []
    if status and status in ("pending", "completed", "declined"):
        where = "WHERE o.status = ?"
        params.append(status)

    total = db._query_one(
        f"SELECT COUNT(*) AS c FROM orders o {where}", tuple(params)
    )["c"]

    rows = db._query_all(
        f"SELECT o.*, u.name AS user_name FROM orders o "
        f"LEFT JOIN users u ON u.id = o.user_id "
        f"{where} ORDER BY o.created_at DESC LIMIT ? OFFSET ?",
        tuple(params) + (limit, offset),
    )
    return {
        "orders": [dict(r) for r in rows],
        "total": total,
        "limit": limit,
        "offset": offset,
    }


# --- Подтверждение и выдача награды -------------------------------------------


def _deliver_reward(con, user_id: int, service: Service) -> None:
    """Автоматически выписывает награду за оплаченную услугу."""
    if service.kind == KIND_COINS:
        con.execute(
            "UPDATE balances SET balance = balance + ?, total_earned = total_earned + ? "
            "WHERE user_id = ?",
            (service.amount, service.amount, user_id),
        )
        game_logic._log_operation(con, user_id, "shop_coins", service.amount, {"svc": service.id})
    elif service.kind == KIND_PREMIUM:
        row = con.execute(
            "SELECT premium_until FROM users WHERE id = ?", (user_id,)
        ).fetchone()
        now = int(time.time())
        base = max(row["premium_until"], now) if row else now
        new_until = base + service.amount * 24 * 60 * 60
        con.execute(
            "UPDATE users SET premium_until = ? WHERE id = ?", (new_until, user_id)
        )
        game_logic._log_operation(con, user_id, "shop_premium", 0, {"svc": service.id, "days": service.amount})


def confirm_order(db: Database, admin_id: int, order_id: int) -> dict:
    """
    Подтверждает оплату и АВТОМАТИЧЕСКИ выдаёт награду.
    Делается админом/владельцем. Повторное подтверждение выдаёт повторно — нет.
    """
    with db.transaction() as con:
        order = con.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
        if not order:
            return {"success": False, "message": "Заявка не найдена"}
        if order["status"] == "completed":
            return {"success": False, "message": "Заявка уже подтверждена"}
        if order["status"] == "declined":
            return {"success": False, "message": "Заявка отклонена"}

        service = get_service(order["service_id"])
        if not service:
            return {"success": False, "message": "Услуга из заявки больше недоступна"}

        # Выдаём награду
        _deliver_reward(con, order["user_id"], service)
        con.execute(
            "UPDATE orders SET status = 'completed', updated_at = ? WHERE id = ?",
            (int(time.time()), order_id),
        )
        return {
            "success": True,
            "message": f"Заявка #{order_id} подтверждена, награда выдана",
            "reward": service.name,
        }


def decline_order(db: Database, admin_id: int, order_id: int) -> dict:
    """Отклоняет заявку (без выдачи награды)."""
    with db.transaction() as con:
        order = con.execute("SELECT * FROM orders WHERE id = ?", (order_id,)).fetchone()
        if not order:
            return {"success": False, "message": "Заявка не найдена"}
        if order["status"] != "pending":
            return {"success": False, "message": "Можно отклонить только новую заявку"}
        con.execute(
            "UPDATE orders SET status = 'declined', updated_at = ? WHERE id = ?",
            (int(time.time()), order_id),
        )
        return {"success": True, "message": f"Заявка #{order_id} отклонена"}