# -*- coding: utf-8 -*-
"""
Работа с базой данных SQLite: подключение, схема, индексы, бэкапы.

Используется встроенный sqlite3 c WAL-режимом и встречами. Все запросы
выполняются параметризованно — это защита от SQL-инъекций.
"""

from __future__ import annotations

import os
import threading
import time
import sqlite3

from backend.config import config

# sqlite3 в Python 3.12+ возвращает float для REAL; нам нужен int повсюду
sqlite3.register_adapter(bool, int)


def _connect(path: str | None = None) -> sqlite3.Connection:
    """Создаёт соединение с нужными pragma и row factory."""
    db_path = path or config.DATABASE_PATH
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(
        db_path,
        check_same_thread=False,  # разрешаем использование из разных потоков
        timeout=30,
    )
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA journal_mode = WAL")
    conn.execute("PRAGMA busy_timeout = 30000")
    return conn


class Database:
    """
    Обёртка над SQLite-хранилищем.

    Держит одно соединение на процесс. Так как доступ к нему идёт из
    потоков FastAPI и из бота, все операции защищены мьютексом (одно
    пишущее подключение одновременно) — это исключает гонки запросов
    для простой СУБД уровня одного процесса.
    """

    def __init__(self, path: str | None = None):
        if path is not None:
            self._path = path
        else:
            self._path = config.DATABASE_PATH
        self._lock = threading.RLock()
        self._conn: sqlite3.Connection | None = None
        self._ensure_dir()

    def _ensure_dir(self) -> None:
        os.makedirs(os.path.dirname(self._path), exist_ok=True)

    # --- управление жизненным циклом ----------------------------------------

    def connect(self) -> None:
        self._ensure_dir()
        self._conn = _connect(self._path)

    def close(self) -> None:
        with self._lock:
            if self._conn is not None:
                self._conn.close()
                self._conn = None

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            raise RuntimeError("Database not connected")
        return self._conn

    # --- транзакции ---------------------------------------------------------

    def transaction(self):
        """Контекстный менеджер транзакции: commit при успехе, rollback при ошибке."""
        return _Transaction(self)

    # --- утилиты ------------------------------------------------------------

    def _execute(self, sql: str, params: tuple = ()):
        """Выполнить запрос внутри блокировки."""
        with self._lock:
            cur = self.conn.execute(sql, params)
            self.conn.commit()
            return cur

    def _query_one(self, sql: str, params: tuple = ()):
        with self._lock:
            cur = self.conn.execute(sql, params)
            row = cur.fetchone()
            return row

    def _query_all(self, sql: str, params: tuple = ()):
        with self._lock:
            cur = self.conn.execute(sql, params)
            return cur.fetchall()

    def backup(self) -> str | None:
        """Создаёт файл-копию базы во вложенную папку backups. Возвращает путь."""
        try:
            os.makedirs(config.BACKUP_DIR, exist_ok=True)
            ts = time.strftime("%Y%m%d_%H%M%S")
            target = os.path.join(config.BACKUP_DIR, f"backup_{ts}.db")
            with self._lock:
                src = sqlite3.connect(self._path)
                dst = sqlite3.connect(target)
                try:
                    src.backup(dst)
                finally:
                    dst.close()
                    src.close()
            self._prune_backups()
            return target
        except Exception:
            # Бэкап не должен ронять сервер
            return None

    def _prune_backups(self, keep: int = 10) -> None:
        """Оставляет только последние `keep` резервных копий."""
        try:
            files = [
                os.path.join(config.BACKUP_DIR, f)
                for f in os.listdir(config.BACKUP_DIR)
                if f.startswith("backup_") and f.endswith(".db")
            ]
            files.sort(key=os.path.getmtime, reverse=True)
            for old in files[keep:]:
                os.remove(old)
        except Exception:
            pass

    def init_schema(self) -> None:
        """Создаёт таблицы, индексы и стартовые данные, если их ещё нет."""
        with self._lock:
            conn = self.conn
            cur = conn.cursor()
            cur.executescript(SCHEMA)
            conn.commit()
            self._migrate()
            # Задания формируются динамически в game.py по дате — отдельная
            # таблица назначений на день не требуется.
            pass

    def _migrate(self) -> None:
        """
        Догоняющие миграции для баз, созданных прежними версиями.
        CREATE TABLE IF NOT EXISTS не добавляет новые столбцы, поэтому
        проверяем их вручную через PRAGMA и добавляем при необходимости.
        """
        with self._lock:
            cur = self.conn.execute("PRAGMA table_info(users)")
            cols = {row[1] for row in cur.fetchall()}
            if "banned" not in cols:
                self.conn.execute(
                    "ALTER TABLE users ADD COLUMN banned INTEGER NOT NULL DEFAULT 0"
                )
            if "ban_reason" not in cols:
                self.conn.execute(
                    "ALTER TABLE users ADD COLUMN ban_reason TEXT NOT NULL DEFAULT ''"
                )
            if "premium_until" not in cols:
                self.conn.execute(
                    "ALTER TABLE users ADD COLUMN premium_until INTEGER NOT NULL DEFAULT 0"
                )
            self.conn.commit()

    # --- доступ к данным пользователя (тонкие обёртки) -----------------------

    def get_user_row(self, user_id: int) -> sqlite3.Row | None:
        return self._query_one(
            "SELECT * FROM users WHERE id = ?", (user_id,)
        )

    def create_user(self, user_id: int, name: str) -> int:
        """Вставляет игрока и возвращает его id."""
        with self._lock:
            cur = self.conn.execute(
                "INSERT INTO users (id, name, created_at) VALUES (?, ?, ?)",
                (user_id, name, int(time.time())),
            )
            self.conn.commit()
            return cur.lastrowid


class _Transaction:
    def __init__(self, db: Database):
        self._db = db

    def __enter__(self):
        self._db._lock.acquire()
        return self._db.conn

    def __exit__(self, exc_type, exc, tb):
        try:
            if exc_type is None:
                self._db.conn.commit()
            else:
                self._db.conn.rollback()
        finally:
            self._db._lock.release()


# ---------------------------------------------------------------------------
# Схема базы данных
# ---------------------------------------------------------------------------

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,          -- Telegram user id
    name TEXT NOT NULL DEFAULT '',
    created_at INTEGER NOT NULL,     -- unix-время регистрации
    last_active INTEGER NOT NULL DEFAULT 0,
    banned INTEGER NOT NULL DEFAULT 0,      -- 1 = забанен
    ban_reason TEXT NOT NULL DEFAULT '',    -- причина бана
    premium_until INTEGER NOT NULL DEFAULT 0 -- unix-время окончания премиума
);

CREATE TABLE IF NOT EXISTS balances (
    user_id INTEGER PRIMARY KEY,
    balance INTEGER NOT NULL DEFAULT 100,
    total_earned INTEGER NOT NULL DEFAULT 0,  -- суммарно заработано (для заданий/достижений)
    last_income_at INTEGER NOT NULL DEFAULT 0, -- unix-время последней начисления дохода
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS businesses (
    user_id INTEGER NOT NULL,
    business_id TEXT NOT NULL,
    level INTEGER NOT NULL DEFAULT 0,   -- 0 = не куплено
    bought_at INTEGER,
    PRIMARY KEY (user_id, business_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS employees (
    user_id INTEGER NOT NULL,
    employee_id TEXT NOT NULL,
    count INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, employee_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS tasks_status (
    user_id INTEGER NOT NULL,
    task_date TEXT NOT NULL,       -- календарный день UTC: YYYY-MM-DD
    task_key TEXT NOT NULL,        -- ключ задания (см. game.py)
    done INTEGER NOT NULL DEFAULT 0,
    claimed INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, task_date, task_key),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS achievements_status (
    user_id INTEGER NOT NULL,
    ach_id TEXT NOT NULL,
    done INTEGER NOT NULL DEFAULT 0,
    claimed INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, ach_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS referrals (
    inviter_id INTEGER NOT NULL,
    invitee_id INTEGER NOT NULL PRIMARY KEY, -- каждый игрок приглашён максимум 1 раз
    reward_given INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL,
    FOREIGN KEY (inviter_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (invitee_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS operation_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    amount_delta INTEGER NOT NULL DEFAULT 0,
    detail TEXT NOT NULL DEFAULT '{}',
    created_at INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Донат-заявки (клиент -> владелец -> подтверждение)
CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,          -- покупатель
    service_id TEXT NOT NULL,          -- id услуги (см. backend/shop.py)
    service_name TEXT NOT NULL,        -- название на момент покупки
    price INTEGER NOT NULL,            -- цена на момент покупки
    status TEXT NOT NULL DEFAULT 'pending', -- pending | confirmed | completed | declined
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Очередь рассылок (создаётся админом, обрабатывается фоновым воркером бота)
CREATE TABLE IF NOT EXISTS broadcasts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id INTEGER NOT NULL,         -- кто создал
    text TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending', -- pending | running | done | cancelled
    total INTEGER NOT NULL DEFAULT 0,
    sent INTEGER NOT NULL DEFAULT 0,   -- сколько отправлено успешно
    failed INTEGER NOT NULL DEFAULT 0, -- сколько с ошибками
    created_at INTEGER NOT NULL,
    started_at INTEGER NOT NULL DEFAULT 0,
    finished_at INTEGER NOT NULL DEFAULT 0
);

-- Счётчик «кому уже отправлено» в рамках конкретной рассылки
CREATE TABLE IF NOT EXISTS broadcast_recipients (
    broadcast_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    PRIMARY KEY (broadcast_id, user_id),
    FOREIGN KEY (broadcast_id) REFERENCES broadcasts(id) ON DELETE CASCADE
);

-- Индексы ------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_balances_user ON balances(user_id);
CREATE INDEX IF NOT EXISTS idx_businesses_user ON businesses(user_id);
CREATE INDEX IF NOT EXISTS idx_employees_user ON employees(user_id);
CREATE INDEX IF NOT EXISTS idx_tasks_user ON tasks_status(user_id, task_date);
CREATE INDEX IF NOT EXISTS idx_achievements_user ON achievements_status(user_id);
CREATE INDEX IF NOT EXISTS idx_referrals_inviter ON referrals(inviter_id);
CREATE INDEX IF NOT EXISTS idx_operations_user ON operation_log(user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id, status);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status, created_at);
CREATE INDEX IF NOT EXISTS idx_broadcasts_admin ON broadcasts(admin_id);
CREATE INDEX IF NOT EXISTS idx_broadcast_recipients ON broadcast_recipients(broadcast_id);
"""


# Глобальный экземпляр базы, разделяемый между модулями
_db: Database | None = None


def get_db() -> Database:
    """Возвращает синглтон базы данных (создаёт при первом обращении)."""
    global _db
    if _db is None:
        _db = Database()
        _db.connect()
        _db.init_schema()
    return _db


def reset_db_for_tests(path: str) -> Database:
    """Создаёт свежую базу по указанному пути (для pytest)."""
    global _db
    if _db is not None:
        _db.close()
    _db = Database(path)
    _db.connect()
    _db.init_schema()
    return _db