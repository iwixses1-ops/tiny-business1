# -*- coding: utf-8 -*-
"""
Настройки приложения из переменных окружения (.env).

Все секреты и параметры развёртывания читаются отсюда. В коде не должно
быть захардкоженных секретов.
"""

from __future__ import annotations

import os

from dotenv import load_dotenv

# Загружаем .env, если он есть (load_dotenv сам пропустит отсутствие файла)
load_dotenv()


class Config:
    """Центральная конфигурация. Доступ к значениям через атрибуты."""

    # --- Telegram ---
    BOT_TOKEN: str = os.getenv("BOT_TOKEN", "").strip()

    # Публичная адресная строка Mini App, открываемая ботом
    WEBAPP_URL: str = os.getenv("WEBAPP_URL", "http://127.0.0.1:8080").strip()

    # --- Аутентификация ---
    # ВАЖНО: об обязательной проверке подписи Telegram — см. ALLOW_LOCAL_TEST.
    # ALLOW_LOCAL_TEST=True разрешает доступ БЕЗ валидной подписи Telegram.
    # Это нужно ТОЛЬКО для локальной разработки. Если False — без валидной
    # подписи initData любой запрос будет отклонён (безопасно для продакшена).
    ALLOW_LOCAL_TEST: bool = os.getenv("ALLOW_LOCAL_TEST", "false").lower() in (
        "1",
        "true",
        "yes",
        "on",
    )

    # Публичное развёртывание: принудительно запрещаем локальный тест.
    # Пара PUBLIC_DEPLOYMENT назначит ALLOW_LOCAL_TEST=False даже если
    # в .env написано true.
    PUBLIC_DEPLOYMENT: bool = os.getenv("PUBLIC_DEPLOYMENT", "false").lower() in (
        "1",
        "true",
        "yes",
        "on",
    )

    # Максимальное время жизни initData (сек). Официально Telegram предлагает
    # не принимать данные старше суток (86400 с). Возьмём 600 с (10 минут),
    # чтобы снизить риск переигрывания устаревших подписей.
    AUTH_MAX_AGE_SECONDS: int = int(os.getenv("AUTH_MAX_AGE_SECONDS", "600"))

    # --- Сеть/сервер ---
    # BACKEND_HOST: в продакшене (Pterodactyl/docker) слушаем 0.0.0.0,
    # чтобы контейнер был доступен снаружи. Локально — 127.0.0.1.
    BACKEND_HOST: str = os.getenv(
        "BACKEND_HOST",
        "0.0.0.0"
        if os.getenv("PUBLIC_DEPLOYMENT", "false").lower()
        in ("1", "true", "yes", "on")
        else "127.0.0.1",
    ).strip()

    # Порт. Pterodactyl/хостинги обычно выдают PORT или SERVER_PORT.
    # Порядок: PORT → SERVER_PORT → BACKEND_PORT → 8080.
    BACKEND_PORT: int = int(
        os.getenv("PORT")
        or os.getenv("SERVER_PORT")
        or os.getenv("BACKEND_PORT")
        or "8080"
    )

    # CORS: разрешённые источники. Для локальной разработки "*" допустимо,
    # но для публики лучше явно указать список. См. README.
    CORS_ORIGINS: list[str] = [
        o.strip()
        for o in os.getenv("CORS_ORIGINS", "*").split(",")
        if o.strip()
    ]

    # --- Frontend (статическая раздача) ---
    FRONTEND_DIR: str = os.getenv(
        "FRONTEND_DIR", os.path.join(os.path.dirname(__file__), "..", "frontend")
    )

    # --- База данных ---
    DATABASE_PATH: str = os.getenv(
        "DATABASE_PATH",
        os.path.join(os.path.dirname(__file__), "..", "data", "tiny_business.db"),
    )

    # Путь к папке бэкапов базы
    BACKUP_DIR: str = os.getenv(
        "BACKUP_DIR",
        os.path.join(os.path.dirname(__file__), "..", "data", "backups"),
    )

    # --- Бот ---
    BOT_AUTO_START: bool = os.getenv("BOT_AUTO_START", "true").lower() in (
        "1",
        "true",
        "yes",
        "on",
    )

    # --- Администраторы ---
    # Список Telegram ID через запятую, например: ADMIN_IDS=123456,789012
    # Только эти пользователи видят и могут использовать админ-панель.
    ADMIN_IDS: list[int] = []
    _raw_admin_ids = os.getenv("ADMIN_IDS", "").strip()
    if _raw_admin_ids:
        for _part in _raw_admin_ids.split(","):
            _part = _part.strip()
            if _part.lstrip("-").isdigit():
                ADMIN_IDS.append(int(_part))

    def is_admin(self, user_id: int | None) -> bool:
        """Является ли пользователь администратором."""
        if user_id is None:
            return False
        return int(user_id) in self.ADMIN_IDS

    # --- Владелец (приём оплаты за донат-услуги) ---
    # Telegram ID владельца. В Mini App на заявке показывается ссылка
    # на владельца (t.me/OWNER_USERNAME), чтобы клиент перешёл и оплатил.
    OWNER_ID: int | None = None
    _raw_owner = os.getenv("OWNER_ID", "").strip()
    if _raw_owner.lstrip("-").isdigit():
        OWNER_ID = int(_raw_owner)

    # Юзернейм владельца (без @) для ссылки t.me/<username>.
    # Если не указан, используется t.me/x звонка по ID.
    OWNER_USERNAME: str = os.getenv("OWNER_USERNAME", "").strip()

    def owner_link(self) -> str:
        """Ссылка для связи с владельцем (для донат-заявок)."""
        if self.OWNER_USERNAME:
            return f"https://t.me/{self.OWNER_USERNAME}"
        if self.OWNER_ID:
            return f"tg://user?id={self.OWNER_ID}"
        return ""

    # --- Рассылка ---
    # Максимум сообщений в минуту (защита от таймаутов Telegram).
    BROADCAST_RATE_PER_MIN: int = int(os.getenv("BROADCAST_RATE_PER_MIN", "20"))
    # Пауза между сообщениями рассылки (сек). Больше — медленнее, но безопаснее.
    BROADCAST_DELAY_SEC: float = float(os.getenv("BROADCAST_DELAY_SEC", "1"))

    def validate(self) -> None:
        """Проверка конфигурации на критичные несоответствия."""
        if self.PUBLIC_DEPLOYMENT and self.ALLOW_LOCAL_TEST:
            # Безопасное решение: в публичном режиме локальный тест запрещён.
            self.ALLOW_LOCAL_TEST = False

        if not self.BOT_TOKEN and self.BOT_AUTO_START:
            # Предупреждение, но не исключение — сервер может работать
            # отдельно от бота во время разработки.
            # Раскомментируй, если хочешь жёстко требовать токен:
            # raise RuntimeError("BOT_TOKEN не задан в .env")
            pass

    @property
    def auth_required(self) -> bool:
        """Нужна ли строгая проверка подписи Telegram (без локального теста)."""
        if self.PUBLIC_DEPLOYMENT:
            return True
        return not self.ALLOW_LOCAL_TEST


config = Config()
config.validate()