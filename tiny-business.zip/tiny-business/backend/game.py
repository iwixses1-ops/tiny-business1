# -*- coding: utf-8 -*-
"""
Ядро игровой логики Tiny Business: баланс, доход, предприятия, сотрудники,
задания, достижения, реферальная система и рейтинг.

ЕДИНЫЙ ИСТОЧНИК ИСТИНЫ находится на сервере. Клиент никогда не передаёт
величину баланса/дохода/уровня — все суммы вычисляются здесь.

Потокобезопасность обеспечивается блокировкой базы (см. Database._lock).
Все операции покупки выполняются в транзакциях.
"""
from __future__ import annotations

import json
import time
import datetime

from backend.database import Database
from backend import economy as eco

# Макс. офлайн-прибыль за один «сеанс»: 8 часов
OFFLINE_CAP_SECONDS = 8 * 60 * 60

# Награда за приглашённого друга (после подтверждённого первого запуска)
REFERRAL_REWARD = 150


# ---------------------------------------------------------------------------
# Внутренние помощники
# ---------------------------------------------------------------------------


def utc_today() -> str:
    """Календарный день в UTC: YYYY-MM-DD."""
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d")


def user_display(user_id: int, name: str) -> str:
    return name.strip() or f"Игрок {user_id}"


# ---------------------------------------------------------------------------
# Создание игрока
# ---------------------------------------------------------------------------


def ensure_player(db: Database, user_id: int, name: str) -> bool:
    """
    Гарантирует наличие игрока. Если игрока не было — создаёт с начальным
    балансом и стартовым предприятием. Возвращает True, если создан новый.

    Защита от гонок: попытка INSERT может упасть по уникальному ключу,
    если два запроса пришли одновременно — тогда перечитываем.
    """
    with db.transaction() as con:
        existing = con.execute("SELECT id FROM users WHERE id = ?", (user_id,)).fetchone()
        if existing:
            # обновим активность
            con.execute(
                "UPDATE users SET last_active = ? WHERE id = ?",
                (int(time.time()), user_id),
            )
            return False

        con.execute(
            "INSERT INTO users (id, name, created_at, last_active) VALUES (?, ?, ?, ?)",
            (user_id, name, int(time.time()), int(time.time())),
        )
        # Баланс
        con.execute(
            "INSERT OR IGNORE INTO balances (user_id, balance, total_earned, last_income_at) "
            "VALUES (?, ?, ?, ?)",
            (user_id, eco.START_BALANCE, 0, int(time.time())),
        )
        # Стартовое предприятие (лимонад на 1 уровне)
        con.execute(
            "INSERT OR IGNORE INTO businesses (user_id, business_id, level, bought_at) "
            "VALUES (?, ?, ?, ?)",
            (user_id, eco.STARTUP_BUSINESS_ID, 1, int(time.time())),
        )
        # Пустые записи сотрудников
        for emp in eco.EMPLOYEES:
            con.execute(
                "INSERT OR IGNORE INTO employees (user_id, employee_id, count) VALUES (?, ?, 0)",
                (user_id, emp),
            )
    return True


def grant_balance(db: Database, uid: int, amount: int) -> None:
    """
    Прямо начисляет баланс (добавляет к текущему). Используется в тестах,
    чтобы подготовить состояние без прохождения игровой логики.
    """
    with db.transaction() as con:
        con.execute(
            "UPDATE balances SET balance = balance + ? WHERE user_id = ?",
            (amount, uid),
        )


# ---------------------------------------------------------------------------
# Доход
# ---------------------------------------------------------------------------


def _business_income_for(user_id: int, business_id: str, level: int) -> int:
    """Доход предприятия с учётом уровня (без сотрудников)."""
    return eco.business_income(eco.BUSINESSES[business_id], level)


def _employee_counts(con, user_id: int) -> dict[str, int]:
    """
    Все нанятые сотрудники одним запросом.

    ОПТИМИЗАЦИЯ: раньше на каждого сотрудника шёл отдельный SELECT, из-за
    чего расчёт дохода был O(предприятия × сотрудники) запросов. Теперь — 1.
    """
    rows = con.execute(
        "SELECT employee_id, count FROM employees WHERE user_id = ?",
        (user_id,),
    ).fetchall()
    return {r["employee_id"]: r["count"] for r in rows}


def is_premium_active(con, user_id: int) -> bool:
    """Активен ли премиум (множитель дохода) у игрока сейчас."""
    row = con.execute(
        "SELECT premium_until FROM users WHERE id = ?", (user_id,)
    ).fetchone()
    if not row or row["premium_until"] <= 0:
        return False
    return row["premium_until"] > int(time.time())


def premium_remaining_seconds(con, user_id: int) -> int:
    """Сколько секунд осталось премиума (0 — если не куплен/истёк)."""
    row = con.execute(
        "SELECT premium_until FROM users WHERE id = ?", (user_id,)
    ).fetchone()
    if not row:
        return 0
    return max(0, row["premium_until"] - int(time.time()))


def money_per_minute(con, user_id: int) -> int:
    """
    Полный доход в минуту: предприятия + бонусы сотрудников + премиум.

    ОПТИМИЗАЦИЯ: 2 запроса (предприятия и сотрудники) вместо
    O(предприятия × сотрудники), расчёт бонусов — в Python.
    """
    rows = con.execute(
        "SELECT business_id, level FROM businesses WHERE user_id = ? AND level > 0",
        (user_id,),
    ).fetchall()
    counts = _employee_counts(con, user_id)

    # Глобальные бонусы (менеджер/директор)
    global_bonus = sum(
        emp.percentage * counts.get(emp.id, 0)
        for emp in eco.EMPLOYEES.values()
        if emp.bonus_kind == "global_mult"
    )

    total = 0.0
    for r in rows:
        bid = r["business_id"]
        base = _business_income_for(user_id, bid, r["level"])
        bonus = sum(
            emp.percentage
            for emp in eco.EMPLOYEES.values()
            if emp.bonus_kind == "business_mult"
            and emp.target_business == bid
            and counts.get(emp.id, 0) > 0
        )
        total += base * (1 + bonus / 100.0)

    total *= (1 + global_bonus / 100.0)

    # Премиум: +50% к доходу
    if is_premium_active(con, user_id):
        total *= eco.PREMIUM_INCOME_MULTIPLIER

    return int(round(total))


def _add_income(con, user_id: int, seconds: int) -> int:
    """
    Прибавляет пассивный доход за `seconds` секунд (внутри транзакции).
    Обновляет total_earned. Возвращает начисленные монеты.
    """
    rate = money_per_minute(con, user_id)
    earned = int((rate * seconds) / 60) if seconds > 0 else 0
    if earned <= 0:
        return 0
    con.execute(
        "UPDATE balances SET balance = balance + ?, total_earned = total_earned + ? "
        "WHERE user_id = ?",
        (earned, earned, user_id),
    )
    return earned


def claim_income(db: Database, user_id: int) -> dict:
    """
    Собирает накопившийся пассивный доход. Вызывается автоматически при
    каждом обращении к /api/me (и вручную по кнопке «Собрать прибыль»).

    Логика начисления (единый источник истины — сервер):
      - Прошедшее время = now - last_income_at.
      - Офлайн-прибыль ограничена OFFLINE_CAP_SECONDS (8 часов).
      - last_income_at двигается ВПЕРЁД ровно на тот период (applied),
        за который мы начислили. Это делает повторное начисление за те же
        секунды невозможным даже при конфликтующих запросах (всё внутри
        транзакции под блокировкой базы).
      - Защита от отрицательного времени: если часы пользователя ушли назад
        (elapsed < 0), ничего не начисляем и не двигаем время.
    """
    with db.transaction() as con:
        bal = con.execute(
            "SELECT * FROM balances WHERE user_id = ?", (user_id,)
        ).fetchone()
        if not bal:
            return {"earned": 0, "applied_seconds": 0, "elapsed": 0, "balance": 0}

        now = int(time.time())
        last = bal["last_income_at"] or now
        elapsed = now - last

        earned = 0
        applied = 0

        if elapsed > 0:
            # Начисляем не больше лимита (8 ч) за период отсутствия.
            capped = min(elapsed, OFFLINE_CAP_SECONDS)
            rate = money_per_minute(con, user_id)
            earned = int((rate * capped) / 60) if capped > 0 else 0
            if earned > 0:
                # ВАЖНО: ставим last_income_at = now, а НЕ «+capped».
                # Если игрок отсутствовал дольше лимита, лишнее время
                # сгорает и не может быть начислено повторными запросами
                # (иначе лимит 8 ч обходился бы несколькими вызовами).
                con.execute(
                    "UPDATE balances SET "
                    " balance = balance + ?, "
                    " total_earned = total_earned + ?, "
                    " last_income_at = ? "
                    "WHERE user_id = ?",
                    (earned, earned, now, user_id),
                )
                _log_operation(con, user_id, "income", earned, {"seconds": capped})
                applied = capped
            elif elapsed > OFFLINE_CAP_SECONDS:
                # Дохода нет (нулевая ставка), но сбрасываем время,
                # чтобы не копился неограниченный «запас».
                con.execute(
                    "UPDATE balances SET last_income_at = ? WHERE user_id = ?",
                    (now, user_id),
                )

        row = con.execute(
            "SELECT balance FROM balances WHERE user_id = ?", (user_id,)
        ).fetchone()
        return {
            "earned": earned,
            "applied_seconds": applied,
            "elapsed": elapsed,
            "balance": row["balance"] if row else 0,
        }


def claim_offline_now(db: Database, user_id: int) -> dict:
    """Принудительный сбор через кнопку «Собрать прибыль» (то же, что claim)."""
    return claim_income(db, user_id)


# ---------------------------------------------------------------------------
# Предприятия
# ---------------------------------------------------------------------------


def buy_business(db: Database, user_id: int, business_id: str) -> dict:
    """
    Открывает предприятие или повышает его уровень. Проверяет средства,
    списывает их и применяет изменения атомарно.
    """
    if not eco.validate_business_id(business_id):
        return {"success": False, "message": "Неизвестное предприятие", "balance": None}

    biz = eco.BUSINESSES[business_id]
    with db.transaction() as con:
        row = con.execute(
            "SELECT level FROM businesses WHERE user_id = ? AND business_id = ?",
            (user_id, business_id),
        ).fetchone()
        level = row["level"] if row else 0

        cost = eco.business_cost(biz, level)
        bal = con.execute(
            "SELECT balance FROM balances WHERE user_id = ?", (user_id,)
        ).fetchone()
        if not bal:
            return {"success": False, "message": "Игрок не найден", "balance": None}
        balance = bal["balance"]
        if balance < cost:
            return {
                "success": False,
                "message": f"Недостаточно монет. Нужно: {cost:,}".replace(",", " "),
                "balance": balance,
            }
        if level >= eco.MAX_BUSINESS_LEVEL:
            return {"success": False, "message": "Максимальный уровень", "balance": balance}

        new_level = level + 1
        con.execute(
            "UPDATE balances SET balance = balance - ? WHERE user_id = ?",
            (cost, user_id),
        )
        con.execute(
            "INSERT INTO businesses (user_id, business_id, level, bought_at) "
            "VALUES (?, ?, ?, ?) "
            "ON CONFLICT(user_id, business_id) DO UPDATE SET level = excluded.level",
            (user_id, business_id, new_level, int(time.time())),
        )
        # Различаем ОТКРЫТИЕ нового предприятия и УЛУЧШЕНИЕ существующего —
        # от этого зависит прогресс ежедневных заданий.
        action = "open_business" if level == 0 else "buy_business"
        _log_operation(con, user_id, action, -cost, {"business": business_id})

        new_bal = con.execute(
            "SELECT balance FROM balances WHERE user_id = ?", (user_id,)
        ).fetchone()["balance"]

        return {
            "success": True,
            "message": f"{biz.emoji} {biz.name} → уровень {new_level}",
            "balance": new_bal,
            "new_level": new_level,
        }


def buy_employee(db: Database, user_id: int, employee_id: str) -> dict:
    """
    Покупает сотрудника. Сотрудники не создаются дважды — их можно покупать
    несколько раз (count увеличивается), но для наглядности V1 позволим
    только одного каждого вида (count ставится 1; повторная покупка = ошибка).
    """
    if not eco.validate_employee_id(employee_id):
        return {"success": False, "message": "Неизвестный сотрудник", "balance": None}

    emp = eco.EMPLOYEES[employee_id]
    with db.transaction() as con:
        row = con.execute(
            "SELECT count FROM employees WHERE user_id = ? AND employee_id = ?",
            (user_id, employee_id),
        ).fetchone()
        count = row["count"] if row else 0

        if count > 0:
            return {
                "success": False,
                "message": "Такой сотрудник уже нанят",
                "balance": None,
            }

        bal = con.execute(
            "SELECT balance FROM balances WHERE user_id = ?", (user_id,)
        ).fetchone()
        if not bal:
            return {"success": False, "message": "Игрок не найден", "balance": None}
        if bal["balance"] < emp.cost:
            return {
                "success": False,
                "message": f"Недостаточно монет. Нужно: {emp.cost:,}".replace(",", " "),
                "balance": bal["balance"],
            }

        con.execute(
            "UPDATE balances SET balance = balance - ? WHERE user_id = ?",
            (emp.cost, user_id),
        )
        con.execute(
            "UPDATE employees SET count = 1 WHERE user_id = ? AND employee_id = ?",
            (user_id, employee_id),
        )
        _log_operation(con, user_id, "buy_employee", -emp.cost, {"employee": employee_id})

        new_bal = con.execute(
            "SELECT balance FROM balances WHERE user_id = ?", (user_id,)
        ).fetchone()["balance"]

        return {
            "success": True,
            "message": f"{emp.emoji} {emp.name} нанят!",
            "balance": new_bal,
        }


# ---------------------------------------------------------------------------
# Задания
# ---------------------------------------------------------------------------


def _active_tasks_for_day(day: str) -> list[eco.DailyTask]:
    """Возвращает задания, активные в конкретный день."""
    # V1: просто первые TASKS_PER_DAY из списка. Для разнообразия можно
    # смешивать по seed дня, но порядок — самый предсказуемый и понятный.
    return eco.AVAILABLE_TASKS[: eco.TASKS_PER_DAY]


def get_tasks(db: Database, user_id: int) -> list[dict]:
    """Возвращает список заданий на сегодня с прогрессом и статусами."""
    ensure_player(db, user_id, f"Игрок {user_id}")
    day = utc_today()
    with db.transaction() as con:
        status = {
            row["task_key"]: row
            for row in con.execute(
                "SELECT * FROM tasks_status WHERE user_id = ? AND task_date = ?",
                (user_id, day),
            ).fetchall()
        }
        progress = _compute_task_progress(con, user_id, day)

        result = []
        for t in _active_tasks_for_day(day):
            srow = status.get(t.task_id)
            done = bool(srow and srow["done"])
            claimed = bool(srow and srow["claimed"])
            prog, target = progress.get(t.task_id, (0, 1))
            result.append(
                {
                    "key": t.task_id,
                    "emoji": t.emoji,
                    "title": t.title,
                    "description": t.description,
                    "reward": t.reward,
                    "progress": prog if prog <= target else target,
                    "target": target,
                    "done": done,
                    "claimed": claimed,
                }
            )
        return result


def _compute_task_progress(con, user_id: int, day: str) -> dict[str, tuple]:
    """Вычисляет прогресс (текущее, цель) по каждому заданию данного дня."""
    today_start = _day_start_utc(day)
    progress: dict[str, tuple] = {}

    # ОПТИМИЗАЦИЯ: всё по журналу операций за сегодня собираем ОДНИМ
    # запросом (раньше было 4 отдельных).
    # «Заработано сегодня» считаем только по ПОЛОЖИТЕЛЬНЫМ операциям —
    # иначе покупки уменьшали бы прогресс задания «собрать монеты».
    agg = con.execute(
        "SELECT "
        " COALESCE(SUM(CASE WHEN amount_delta > 0 THEN amount_delta ELSE 0 END), 0) AS earned, "
        " SUM(CASE WHEN action = 'buy_business' THEN 1 ELSE 0 END) AS upgrades, "
        " SUM(CASE WHEN action = 'open_business' THEN 1 ELSE 0 END) AS opened, "
        " SUM(CASE WHEN action = 'buy_employee' THEN 1 ELSE 0 END) AS hired "
        "FROM operation_log WHERE user_id = ? AND created_at >= ?",
        (user_id, today_start),
    ).fetchone()
    earned_today = agg["earned"] or 0
    upgrades_today = agg["upgrades"] or 0
    opened_today = agg["opened"] or 0
    hired_today = agg["hired"] or 0

    progress["login"] = (1, 1)

    # Задания «собрать монеты» — цель по заработанному за сегодня
    progress["collect_50"] = (earned_today, 50)
    progress["collect_200"] = (earned_today, 200)

    # Действия дня (улучшение / открытие / найм)
    progress["buy_upgrade"] = (upgrades_today, 1)
    progress["open_business"] = (opened_today, 1)
    progress["hire_employee"] = (hired_today, 1)

    # Суммарно заработано за всё время
    row = con.execute(
        "SELECT total_earned FROM balances WHERE user_id = ?", (user_id,)
    ).fetchone()
    progress["total_collect_1000"] = ((row["total_earned"] if row else 0), 1000)

    return progress


def _day_start_utc(day: str) -> int:
    """Unix-время начала дня в UTC."""
    return int(
        datetime.datetime.strptime(day, "%Y-%m-%d")
        .replace(tzinfo=datetime.timezone.utc)
        .timestamp()
    )


def update_task_progress(db: Database, user_id: int, event: str) -> None:
    """
    Вызывается после игровых событий, чтобы проверить задания текущего дня
    и пометить их выполненными (status → done). Награда — только через claim.
    """
    ensure_player(db, user_id, f"Игрок {user_id}")
    day = utc_today()
    with db.transaction() as con:
        _check_tasks_done(con, user_id, day, event)


def _check_tasks_done(con, user_id: int, day: str, event: str = "") -> None:
    progress = _compute_task_progress(con, user_id, day)
    active = {t.task_id: t for t in _active_tasks_for_day(day)}

    for key, (prog, target) in progress.items():
        if key not in active:
            continue
        if prog >= target and not _is_task_claimed(con, user_id, day, key):
            # Помечаем выполненным, если ещё не завершено
            con.execute(
                "INSERT INTO tasks_status (user_id, task_date, task_key, done, claimed) "
                "VALUES (?, ?, ?, 1, 0) "
                "ON CONFLICT(user_id, task_date, task_key) "
                "DO UPDATE SET done = 1 WHERE claimed = 0",
                (user_id, day, key),
            )


def _is_task_claimed(con, user_id: int, day: str, key: str) -> bool:
    row = con.execute(
        "SELECT done, claimed FROM tasks_status WHERE user_id = ? AND task_date = ? AND task_key = ?",
        (user_id, day, key),
    ).fetchone()
    return bool(row and row["claimed"])


def claim_task(db: Database, user_id: int, task_key: str) -> dict:
    """Забирает награду за выполненное задание (однократно)."""
    day = utc_today()
    with db.transaction() as con:
        task = next((t for t in _active_tasks_for_day(day) if t.task_id == task_key), None)
        if not task:
            return {"success": False, "message": "Задание недоступно", "balance": None}

        row = con.execute(
            "SELECT done, claimed FROM tasks_status WHERE user_id = ? AND task_date = ? AND task_key = ?",
            (user_id, day, task_key),
        ).fetchone()

        if not row or not row["done"]:
            return {"success": False, "message": "Задание ещё не выполнено", "balance": None}
        if row["claimed"]:
            return {"success": False, "message": "Награда уже получена", "balance": None}

        con.execute(
            "UPDATE tasks_status SET claimed = 1 WHERE user_id = ? AND task_date = ? AND task_key = ?",
            (user_id, day, task_key),
        )
        con.execute(
            "UPDATE balances SET balance = balance + ? WHERE user_id = ?",
            (task.reward, user_id),
        )
        _log_operation(con, user_id, "claim_task", task.reward, {"task": task_key})

        new_bal = con.execute(
            "SELECT balance FROM balances WHERE user_id = ?", (user_id,)
        ).fetchone()["balance"]
        return {"success": True, "message": f"Получено {task.reward} монет", "balance": new_bal}


# ---------------------------------------------------------------------------
# Достижения
# ---------------------------------------------------------------------------


def update_achievements(db: Database, user_id: int) -> list[dict]:
    """
    Проверяет достижения и возвращает список ТОЛЬКО что открытых (для уведомления).
    Валидность условия и награды — на сервере; приём повторно невозможен.
    """
    ensure_player(db, user_id, f"Игрок {user_id}")
    with db.transaction() as con:
        state = {
            row["ach_id"]: row
            for row in con.execute(
                "SELECT * FROM achievements_status WHERE user_id = ?", (user_id,)
            ).fetchall()
        }
        metrics = _achievement_metrics(con, user_id)

        newly = []
        for ach in eco.ACHIEVEMENTS:
            met = metrics.get(ach.ach_id, False)
            row = state.get(ach.ach_id)
            done = bool(row and row["claimed"]) or bool(row and row["done"])
            if met and not done:
                # Открыто сейчас: ставим done=0, claimed=0; награду выдаём
                # сразу и здесь, чтобы не гонять отдельный claim.
                existed_done = bool(row and row["done"])
                if not existed_done:
                    con.execute(
                        "UPDATE balances SET balance = balance + ? WHERE user_id = ?",
                        (ach.reward, user_id),
                    )
                    _log_operation(con, user_id, "achievement", ach.reward, {"ach": ach.ach_id})
                    con.execute(
                        "INSERT INTO achievements_status (user_id, ach_id, done, claimed) "
                        "VALUES (?, ?, 1, 1) "
                        "ON CONFLICT(user_id, ach_id) "
                        "DO UPDATE SET done = 1, claimed = 1",
                        (user_id, ach.ach_id),
                    )
                    newly.append(
                        {
                            "ach_id": ach.ach_id,
                            "emoji": ach.emoji,
                            "title": ach.title,
                            "description": ach.description,
                            "reward": ach.reward,
                            "done": True,
                            "claimed": True,
                        }
                    )
        return newly


def _achievement_metrics(con, user_id: int) -> dict[str, bool]:
    m: dict[str, bool] = {}

    # ОПТИМИЗАЦИЯ: предприятия читаем ОДНИМ запросом (раньше было 3),
    # все вычисления — в Python.
    rows = con.execute(
        "SELECT business_id, level FROM businesses WHERE user_id = ?",
        (user_id,),
    ).fetchall()
    owned_rows = [r for r in rows if r["level"] > 0]
    owned = len(owned_rows)

    # «Первый бизнес» — открытие первого ПЛАТНОГО предприятия
    # (стартовый лимонад бесплатный: иначе новый игрок сразу получал бы
    #  награду и терял ровно стартовые 100 монет).
    paid_owned = sum(
        1 for r in owned_rows
        if eco.BUSINESSES[r["business_id"]].base_cost > 0
    )
    m["first_business"] = paid_owned >= 1
    m["three_businesses"] = owned >= 3

    # Первое улучшение: любой бизнес на уровне >= 2
    m["first_upgrade"] = any(r["level"] >= 2 for r in rows)
    # 10 улучшений: суммарный прирост уровней (level-1) по всем бизнесам
    m["ten_upgrades"] = sum(max(0, r["level"] - 1) for r in rows) >= 10

    # Первые 1000 заработанных монет (суммарно)
    bal = con.execute(
        "SELECT total_earned FROM balances WHERE user_id = ?", (user_id,)
    ).fetchone()
    m["first_1000"] = (bal["total_earned"] if bal else 0) >= 1000

    # Первый сотрудник
    hired = con.execute(
        "SELECT COUNT(*) AS c FROM employees WHERE user_id = ? AND count > 0",
        (user_id,),
    ).fetchone()["c"]
    m["first_employee"] = hired >= 1
    return m


def get_achievements(db: Database, user_id: int) -> list[dict]:
    ensure_player(db, user_id, f"Игрок {user_id}")
    with db.transaction() as con:
        state = {
            row["ach_id"]: row
            for row in con.execute(
                "SELECT * FROM achievements_status WHERE user_id = ?", (user_id,)
            ).fetchall()
        }
        metrics = _achievement_metrics(con, user_id)
        out = []
        for ach in eco.ACHIEVEMENTS:
            met = metrics.get(ach.ach_id, False)
            row = state.get(ach.ach_id)
            done = bool(met) or bool(row and row["done"])
            claimed = bool(row and row["claimed"])
            out.append(
                {
                    "ach_id": ach.ach_id,
                    "emoji": ach.emoji,
                    "title": ach.title,
                    "description": ach.description,
                    "reward": ach.reward,
                    "done": done,
                    "claimed": claimed,
                }
            )
        return out


# ---------------------------------------------------------------------------
# Реферальная система
# ---------------------------------------------------------------------------


def build_referral_link(user_id: int) -> str:
    """Ссылка для приглашения друзей (Telegram deep link)."""
    return f"https://t.me/TinyBusinessBot?start=ref_{user_id}"


def process_referral(db: Database, user_id: int, inviter_id: int) -> dict:
    """
    При подтверждённом первом запуске новым игроком выдаёт награду пригласившему.
    Правила:
      - никто не может пригласить сам себя;
      - один invitee привязывается только к одному инвайтефу;
      - награда за одного приглашённого выдаётся только один раз.
    """
    if inviter_id == user_id:
        return {"success": False, "message": "Нельзя пригласить самого себя"}

    with db.transaction() as con:
        existing = con.execute(
            "SELECT * FROM referrals WHERE invitee_id = ?", (user_id,)
        ).fetchone()
        if existing:
            return {"success": False, "message": "Игрок уже приглашён кем-то"}

        # Приглашающий должен существовать как игрок
        inv = con.execute("SELECT id FROM users WHERE id = ?", (inviter_id,)).fetchone()
        if not inv:
            return {"success": False, "message": "Приглашающий не найден"}

        con.execute(
            "INSERT INTO referrals (inviter_id, invitee_id, reward_given, created_at) "
            "VALUES (?, ?, ?, ?)",
            (inviter_id, user_id, 1, int(time.time())),
        )
        con.execute(
            "UPDATE balances SET balance = balance + ? WHERE user_id = ?",
            (REFERRAL_REWARD, inviter_id),
        )
        _log_operation(con, inviter_id, "referral", REFERRAL_REWARD, {"invitee": user_id})
        return {
            "success": True,
            "message": f"Друг приглашён, +{REFERRAL_REWARD} монет",
            "balance": None,
        }


def get_referral_info(db: Database, user_id: int) -> dict:
    ensure_player(db, user_id, f"Игрок {user_id}")
    with db.transaction() as con:
        invited = con.execute(
            "SELECT COUNT(*) AS c FROM referrals WHERE inviter_id = ?", (user_id,)
        ).fetchone()["c"]
        return {
            "referral_link": build_referral_link(user_id),
            "invited_count": invited,
            "reward": REFERRAL_REWARD,
            "can_get_more": True,
        }


# ---------------------------------------------------------------------------
# Рейтинг
# ---------------------------------------------------------------------------


def get_leaderboard(db: Database, user_id: int) -> dict:
    """Топ-10 по балансу + позиция текущего игрока."""
    ensure_player(db, user_id, f"Игрок {user_id}")
    with db.transaction() as con:
        rows = con.execute(
            "SELECT u.id, u.name, b.balance FROM users u "
            "JOIN balances b ON b.user_id = u.id "
            "ORDER BY b.balance DESC, u.id ASC "
            "LIMIT ?",
            (eco.LEADERBOARD_SIZE,),
        ).fetchall()

        board = []
        for i, r in enumerate(rows, start=1):
            board.append(
                {
                    "position": i,
                    "name": (r["name"] or f"Игрок {r['id']}")[:24],
                    "balance": r["balance"],
                }
            )

        # Позиция текущего игрока считаем по рангу всех игроков
        me_balance = con.execute(
            "SELECT balance FROM balances WHERE user_id = ?", (user_id,)
        ).fetchone()
        player_row = None
        if me_balance:
            better = con.execute(
                "SELECT COUNT(*) AS c FROM balances WHERE balance > ?",
                (me_balance["balance"],),
            ).fetchone()["c"]
            pos = better + 1
            name_row = con.execute(
                "SELECT name FROM users WHERE id = ?", (user_id,)
            ).fetchone()
            player_row = {
                "position": pos,
                "name": (name_row["name"] or f"Игрок {user_id}")[:24],
                "balance": me_balance["balance"],
            }
        return {"rows": board, "player": player_row}


# ---------------------------------------------------------------------------
# Сводное состояние для /api/me
# ---------------------------------------------------------------------------


def get_me(db: Database, user_id: int, name: str) -> dict:
    ensure_player(db, user_id, name)

    # Прежде чем возвращать состояние — собираем доход за прошедшее время
    claim_income(db, user_id)

    # Проверяем достижения и выдаём награды (отдельной транзакцией)
    newly_achs = update_achievements(db, user_id)

    with db.transaction() as con:
        u = con.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
        bal = con.execute(
            "SELECT * FROM balances WHERE user_id = ?", (user_id,)
        ).fetchone()
        biz_rows = con.execute(
            "SELECT * FROM businesses WHERE user_id = ?", (user_id,)
        ).fetchall()
        emp_rows = con.execute(
            "SELECT * FROM employees WHERE user_id = ?", (user_id,)
        ).fetchall()

        # Строим бизнесы
        level_map = {r["business_id"]: r["level"] for r in biz_rows}
        businesses = []
        for biz in eco.businesses_ordered():
            level = level_map.get(biz.id, 0)
            owned = level > 0
            businesses.append(
                {
                    "business_id": biz.id,
                    "name": biz.name,
                    "emoji": biz.emoji,
                    "level": level,
                    "owned": owned,
                    "base_cost": biz.base_cost,
                    "base_income": biz.base_income,
                    "next_cost": eco.business_cost(biz, level),
                    "income": _business_income_for(user_id, biz.id, level),
                    "description": biz.description,
                }
            )

        emp_count = {r["employee_id"]: r["count"] for r in emp_rows}
        employees = []
        for emp in eco.EMPLOYEES.values():
            employees.append(
                {
                    "employee_id": emp.id,
                    "name": emp.name,
                    "emoji": emp.emoji,
                    "cost": emp.cost,
                    "count": emp_count.get(emp.id, 0),
                    "bonus_kind": emp.bonus_kind,
                    "percentage": emp.percentage,
                    "bonus_description": (
                        f"+{emp.percentage}% к доходу {'всего' if emp.bonus_kind=='global_mult' else 'своего бизнеса'}"
                    ),
                }
            )

        money_per_min = money_per_minute(con, user_id)
        prem_active = is_premium_active(con, user_id)
        prem_remaining = premium_remaining_seconds(con, user_id)

        return {
            "user": {
                "id": u["id"],
                "name": u["name"],
                "first_name": u["name"],
                "username": None,
                "created_at": u["created_at"],
                "last_active": u["last_active"],
            },
            "balance": bal["balance"],
            "total_earned": bal["total_earned"],
            "money_per_min": money_per_min,
            "premium_active": prem_active,
            "premium_remaining": prem_remaining,
            "premium_multiplier": eco.PREMIUM_INCOME_MULTIPLIER if prem_active else 1,
            "offline_pending": 0,
            "offline_seconds": 0,
            "businesses": businesses,
            "employees": employees,
            "newly_achievements": newly_achs,
        }


# ---------------------------------------------------------------------------
# Журнал операций
# ---------------------------------------------------------------------------


def _log_operation(con, user_id: int, action: str, amount_delta: int, detail: dict) -> None:
    con.execute(
        "INSERT INTO operation_log (user_id, action, amount_delta, detail, created_at) "
        "VALUES (?, ?, ?, ?, ?)",
        (user_id, action, amount_delta, json.dumps(detail, ensure_ascii=False), int(time.time())),
    )