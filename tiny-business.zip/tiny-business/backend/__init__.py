# -*- coding: utf-8 -*-
"""Пакет backend: серверная часть Tiny Business (FastAPI + хранилище)."""