# -*- coding: utf-8 -*-
"""
FastAPI-приложение Tiny Business.

Служит REST API для Mini App и раздаёт статику frontend.
Аутентификация — по подписи Telegram initData через заголовок
Authorization: tma <initData> (или X-Telegram-Init-Data).
"""
from __future__ import annotations

import time
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import Depends, FastAPI, Header, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from backend import auth
from backend import game as game_logic
from backend import admin as admin_logic
from backend.config import config
from backend.database import get_db
from backend.models import (
    AdminBanIn,
    AdminGrantIn,
    AdminOrderIn,
    AdminUserIn,
    BroadcastIn,
    ShopOrderIn,
)
from backend import shop as shop_logic
from backend.broadcast import broadcast_create, broadcast_list

# --- lifespan -----------------------------------------------------------------


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Инициализация базы при старте
    db = get_db()
    db.init_schema()
    # Плановый бэкап при первом старте дня (простой вариант — при запуске)
    db.backup()
    yield
    db.close()


app = FastAPI(
    title="Tiny Business API",
    version="1.0.0",
    lifespan=lifespan,
)

# --- CORS ---------------------------------------------------------------------
# Для локальной разработки разрешаем всё. Для продакшена задай явный список
# через CORS_ORIGINS в .env (например https://your-app.onrender.com).
app.add_middleware(
    CORSMiddleware,
    allow_origins=config.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- Аутентификация ------------------------------------------------------------


def get_current_user(
    authorization: Optional[str] = Header(default=None),
    x_telegram_init_data: Optional[str] = Header(default=None),
) -> tuple[int, str]:
    """
    FastAPI-зависимость: извлекает и проверяет initData, возвращает
    (user_id, имя). При любой ошибке отвечает 401.

    В локальном тестовом режиме (ALLOW_LOCAL_TEST=true и не PUBLIC_DEPLOYMENT)
    доступ разрешён даже без подписи — это только для разработки.
    """
    init_data = None
    if authorization and authorization.lower().startswith("tma "):
        init_data = authorization[4:].strip()
    elif x_telegram_init_data:
        init_data = x_telegram_init_data.strip()

    # Локальный тестовый режим: разрешаем без подписи (безопасно только в dev)
    if not init_data:
        if config.auth_required:
            raise HTTPException(status_code=401, detail="Missing initData")
        result = auth.validate_init_data("")
    else:
        result = auth.validate_init_data(init_data)

    if result is None:
        raise HTTPException(status_code=401, detail="Invalid initData signature")

    user_id, name = result
    return user_id, name


def get_player(user: tuple[int, str] = Depends(get_current_user)) -> tuple[int, str]:
    """
    Зависимость для игровых маршрутов: как get_current_user, но ещё и
    отсекает забаненных игроков (403).
    """
    user_id, name = user
    if admin_logic.is_banned(get_db(), user_id):
        raise HTTPException(status_code=403, detail="Вы забанены в игре")
    return user_id, name


def require_admin(user: tuple[int, str] = Depends(get_current_user)) -> tuple[int, str]:
    """
    Зависимость для админ-маршрутов: пропускает только пользователей из
    ADMIN_IDS. Остальным — 403.
    """
    user_id, name = user
    if not admin_logic.is_admin(user_id):
        raise HTTPException(status_code=403, detail="Доступ только для администраторов")
    return user_id, name


# --- Служебные обёртки ответов --------------------------------------------------

def _ok(data: dict) -> dict:
    return {"ok": True, "data": data}


def _err(message: str, code: int = 400) -> dict:
    return {"ok": False, "error": message}


# --- Маршруты API ---------------------------------------------------------------


@app.get("/api/ping")
def ping():
    return {"ok": True, "message": "pong", "time": int(time.time())}


@app.get("/api/me")
def api_me(user: tuple[int, str] = Depends(get_player)):
    user_id, name = user
    data = game_logic.get_me(get_db(), user_id, name)
    return _ok(data)


@app.get("/api/businesses")
def api_businesses(user: tuple[int, str] = Depends(get_player)):
    user_id, name = user
    me = game_logic.get_me(get_db(), user_id, name)
    return _ok({"businesses": me["businesses"]})


@app.post("/api/businesses/{business_id}/buy")
def api_buy_business(
    business_id: str,
    user: tuple[int, str] = Depends(get_player),
):
    user_id, name = user
    db = get_db()
    res = game_logic.buy_business(db, user_id, business_id)
    if not res["success"]:
        return _err(res["message"])
    # Обновляем задания и достижения после «покупки/улучшения»
    game_logic.update_task_progress(db, user_id, "business")
    game_logic.update_achievements(db, user_id)
    return _ok(res)


@app.post("/api/businesses/{business_id}/upgrade")
def api_upgrade(
    business_id: str,
    user: tuple[int, str] = Depends(get_player),
):
    # Улучшение обрабатывается тем же методом buy_business (у всех бизнесов,
    # кроме базового, первый уровень — открытие; дальше — улучшение).
    user_id, name = user
    db = get_db()
    res = game_logic.buy_business(db, user_id, business_id)
    if not res["success"]:
        return _err(res["message"])
    game_logic.update_task_progress(db, user_id, "upgrade")
    game_logic.update_achievements(db, user_id)
    return _ok(res)


@app.post("/api/employees/{employee_id}/buy")
def api_buy_employee(
    employee_id: str,
    user: tuple[int, str] = Depends(get_player),
):
    user_id, name = user
    db = get_db()
    res = game_logic.buy_employee(db, user_id, employee_id)
    if not res["success"]:
        return _err(res["message"])
    game_logic.update_task_progress(db, user_id, "employee")
    game_logic.update_achievements(db, user_id)
    return _ok(res)


@app.post("/api/collect")
def api_collect(user: tuple[int, str] = Depends(get_player)):
    user_id, name = user
    db = get_db()
    res = game_logic.claim_income(db, user_id)
    return _ok(res)


@app.get("/api/tasks")
def api_tasks(user: tuple[int, str] = Depends(get_player)):
    user_id, name = user
    db = get_db()
    game_logic.update_task_progress(db, user_id, "view")
    tasks = game_logic.get_tasks(db, user_id)
    return _ok({"tasks": tasks})


@app.get("/api/tasks/{task_key}/progress")
def api_task_progress(
    task_key: str,
    user: tuple[int, str] = Depends(get_player),
):
    # Простая заглушка для совместимости; прогресс уже в /api/tasks
    user_id, name = user
    db = get_db()
    tasks = game_logic.get_tasks(db, user_id)
    for t in tasks:
        if t["key"] == task_key:
            return _ok(t)
    return _err("Задание не найдено", 404)


@app.post("/api/tasks/{task_key}/claim")
def api_claim_task(
    task_key: str,
    user: tuple[int, str] = Depends(get_player),
):
    user_id, name = user
    db = get_db()
    res = game_logic.claim_task(db, user_id, task_key)
    if not res["success"]:
        return _err(res["message"])
    return _ok(res)


@app.get("/api/achievements")
def api_achievements(user: tuple[int, str] = Depends(get_player)):
    user_id, name = user
    db = get_db()
    game_logic.update_achievements(db, user_id)
    ach = game_logic.get_achievements(db, user_id)
    return _ok({"achievements": ach})


@app.get("/api/leaderboard")
def api_leaderboard(user: tuple[int, str] = Depends(get_player)):
    user_id, name = user
    db = get_db()
    res = game_logic.get_leaderboard(db, user_id)
    return _ok(res)


@app.get("/api/referral")
def api_referral(user: tuple[int, str] = Depends(get_player)):
    user_id, name = user
    db = get_db()
    res = game_logic.get_referral_info(db, user_id)
    return _ok(res)


# --- Реферальный deep link: обрабатывается ботом, но сервер тоже может
# --- отметить, что пользователь пришёл по приглашению (если передать ref)
@app.get("/api/referral/accept")
def api_referral_accept(
    ref: str = Query(default=""),
    user: tuple[int, str] = Depends(get_player),
):
    """
    Вызывается frontend при первом запуске, если пользователь перешёл по
    ссылке ?startapp=ref_XXX. Передаём inviter_id явно, сервер проверяет.
    """
    user_id, name = user
    if not ref:
        return _err("Нет параметра ref")
    try:
        inviter_id = int(ref.replace("ref_", ""))
    except ValueError:
        return _err("Неверный ref")
    db = get_db()
    # Убедимся, что новый игрок зарегистрирован (иначе награды не будет)
    game_logic.ensure_player(db, user_id, name)
    res = game_logic.process_referral(db, user_id, inviter_id)
    if not res["success"]:
        return _err(res["message"])
    return _ok(res)


# --- Админ-панель (только для ADMIN_IDS) --------------------------------------


@app.get("/api/admin/check")
def api_admin_check(user: tuple[int, str] = Depends(get_current_user)):
    """Проверка: является ли текущий пользователь админом (для UI)."""
    user_id, _ = user
    return _ok({"is_admin": admin_logic.is_admin(user_id)})


@app.get("/api/admin/stats")
def api_admin_stats(user: tuple[int, str] = Depends(require_admin)):
    """Общая статистика игры."""
    return _ok(admin_logic.stats(get_db()))


@app.get("/api/admin/users")
def api_admin_users(
    q: str = Query(default=""),
    limit: int = Query(default=20, ge=1, le=50),
    offset: int = Query(default=0, ge=0),
    user: tuple[int, str] = Depends(require_admin),
):
    """Поиск игроков по ID или имени."""
    return _ok(admin_logic.list_users(get_db(), q, limit, offset))


@app.post("/api/admin/grant")
def api_admin_grant(
    payload: AdminGrantIn,
    user: tuple[int, str] = Depends(require_admin),
):
    """Выдать игроку ресурсы (монеты/предприятия/сотрудников/всё)."""
    res = admin_logic.grant(
        get_db(),
        payload.user_id,
        payload.kind,
        amount=payload.amount,
        business_id=payload.business_id,
        level=payload.level,
        employee_id=payload.employee_id,
    )
    if not res["success"]:
        return _err(res["message"])
    return _ok(res)


@app.post("/api/admin/ban")
def api_admin_ban(
    payload: AdminBanIn,
    user: tuple[int, str] = Depends(require_admin),
):
    """Забанить игрока."""
    res = admin_logic.ban(get_db(), payload.user_id, payload.reason)
    if not res["success"]:
        return _err(res["message"])
    return _ok(res)


@app.post("/api/admin/unban")
def api_admin_unban(
    payload: AdminUserIn,
    user: tuple[int, str] = Depends(require_admin),
):
    """Разбанить игрока."""
    res = admin_logic.unban(get_db(), payload.user_id)
    if not res["success"]:
        return _err(res["message"])
    return _ok(res)


@app.post("/api/admin/reset")
def api_admin_reset(
    payload: AdminUserIn,
    user: tuple[int, str] = Depends(require_admin),
):
    """Сбросить прогресс игрока."""
    res = admin_logic.reset_progress(get_db(), payload.user_id)
    if not res["success"]:
        return _err(res["message"])
    return _ok(res)


# --- Донат-магазин (для игроков) ----------------------------------------------


@app.get("/api/shop/services")
def api_shop_services(user: tuple[int, str] = Depends(get_player)):
    """Каталог услуг с ценами и подробными описаниями."""
    return _ok({"services": shop_logic.list_services(), "owner_link": config.owner_link()})


@app.post("/api/shop/buy")
def api_shop_buy(
    payload: ShopOrderIn,
    user: tuple[int, str] = Depends(get_player),
):
    """Создаёт донат-заявку (оплата у владельца, награда после подтверждения)."""
    user_id, _ = user
    res = shop_logic.create_order(get_db(), user_id, payload.service_id)
    if not res["success"]:
        return _err(res["message"])
    return _ok(res)


@app.get("/api/shop/orders")
def api_shop_my_orders(user: tuple[int, str] = Depends(get_player)):
    """История донат-заявок текущего игрока."""
    user_id, _ = user
    return _ok({"orders": shop_logic.list_user_orders(get_db(), user_id)})


# --- Админ: заявки и рассылка ------------------------------------------------


@app.get("/api/admin/orders")
def api_admin_orders(
    status: str = Query(default=""),
    limit: int = Query(default=20, ge=1, le=50),
    offset: int = Query(default=0, ge=0),
    user: tuple[int, str] = Depends(require_admin),
):
    """Список донат-заявок (status: pending/completed/declined/пусто)."""
    return _ok(
        shop_logic.admin_list_orders(get_db(), status or None, limit, offset)
    )


@app.post("/api/admin/orders/confirm")
def api_admin_order_confirm(
    payload: AdminOrderIn,
    user: tuple[int, str] = Depends(require_admin),
):
    """Подтвердить оплату и автоматически выдать награду."""
    admin_id, _ = user
    res = shop_logic.confirm_order(get_db(), admin_id, payload.order_id)
    if not res["success"]:
        return _err(res["message"])
    return _ok(res)


@app.post("/api/admin/orders/decline")
def api_admin_order_decline(
    payload: AdminOrderIn,
    user: tuple[int, str] = Depends(require_admin),
):
    """Отклонить заявку (награда не выдаётся)."""
    admin_id, _ = user
    res = shop_logic.decline_order(get_db(), admin_id, payload.order_id)
    if not res["success"]:
        return _err(res["message"])
    return _ok(res)


@app.post("/api/admin/broadcast")
def api_admin_broadcast(
    payload: BroadcastIn,
    user: tuple[int, str] = Depends(require_admin),
):
    """Запускает рассылку по всем игрокам (фоновая, см. бот-воркер)."""
    admin_id, _ = user
    res = broadcast_create(get_db(), admin_id, payload.text)
    return _ok(res)


@app.get("/api/admin/broadcasts")
def api_admin_broadcasts(user: tuple[int, str] = Depends(require_admin)):
    """Список рассылок и их статус."""
    return _ok({"broadcasts": broadcast_list(get_db())})


# --- Раздача статики frontend --------------------------------------------------
# Статические файлы Mini App. Включаем только если папка существует.
import os

_frontend = os.path.abspath(config.FRONTEND_DIR)
if os.path.isdir(_frontend):
    app.mount(
        "/",
        StaticFiles(directory=_frontend, html=True),
        name="frontend",
    )


# Удобная функция для локального запуска: python -m backend.main
if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "backend.main:app",
        host=config.BACKEND_HOST,
        port=config.BACKEND_PORT,
        reload=True,
    )