# -*- coding: utf-8 -*-
"""Собирает ZIP-архив проекта (без .venv и служебных/секретных файлов)."""
import os
import zipfile

ROOT = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(os.path.dirname(ROOT), "tiny-business.zip")

EXCLUDE_DIRS = {
    ".venv",
    "__pycache__",
    ".pytest_cache",
    "data",
}
EXCLUDE_FILES = {
    ".env",        # секрет
    ".env.local",
    "dev_server.py",  # вспомогательный локальный сервер фронта
}


def main():
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as zf:
        for dirpath, dirnames, filenames in os.walk(ROOT):
            dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS]
            for fname in filenames:
                if fname in EXCLUDE_FILES:
                    continue
                full = os.path.join(dirpath, fname)
                rel = os.path.relpath(full, ROOT)
                zf.write(full, os.path.join("tiny-business", rel))
    print("Created:", OUT)


if __name__ == "__main__":
    main()