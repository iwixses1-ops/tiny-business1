# -*- coding: utf-8 -*-
"""Пакет bot: Telegram-бот Tiny Business (aiogram 3)."""