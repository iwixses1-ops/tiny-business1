# -*- coding: utf-8 -*-
"""
Telegram-бот Tiny Business — ПОЛНОСТЬЮ ботовая версия без Mini App.

Вся игра идёт через инлайн-кнопки (InlineKeyboardMarkup):
  - Главное меню
  - Бизнесы (открыть / улучшить)
  - Сотрудники (нанять)
  - Задания (забрать награду)
  - Достижения
  - Рейтинг
  - Профиль / реферальная ссылка

Обработчики регистрируются в main() через dp.message.register() /
dp.callback_query.register() — это правильный паттерн aiogram 3.
"""

from __future__ import annotations

import asyncio
import logging

from aiogram import BaseMiddleware, Bot, Dispatcher, F, html
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
    TelegramObject,
    WebAppInfo,
)

from backend import admin as admin_logic
from backend import broadcast as broadcast_logic
from backend import game as game_logic
from backend.config import config
from backend.database import get_db

logger = logging.getLogger("tiny_business.bot")

# --- Константы колбэков ------------------------------------------------------

CB_HOME = "home"
CB_BUSINESSES = "biz_list"
CB_EMPLOYEES = "emp_list"
CB_TASKS = "tasks"
CB_ACHIEVEMENTS = "ach"
CB_LEADERBOARD = "top"
CB_PROFILE = "profile"

# Префиксы действий
BUY_BIZ = "buy_biz"       # покупаем/улучшаем бизнес: buy_biz:{id}
BUY_EMP = "buy_emp"       # нанимаем сотрудника: buy_emp:{id}
CLAIM_TASK = "claim_task" # забираем награду задания: claim_task:{key}


def _webapp_button() -> InlineKeyboardButton | None:
    """
    Кнопка открытия Mini App.

    Показывается только если WEBAPP_URL начинается с https:// — Telegram
    не принимает http-адреса для Web App. В локальном режиме кнопки нет.
    """
    url = (config.WEBAPP_URL or "").strip()
    if url.startswith("https://"):
        return InlineKeyboardButton(text="🚀 Играть (Mini App)", web_app=WebAppInfo(url=url))
    return None


def _home_kb() -> InlineKeyboardMarkup:
    """Клавиатура главного меню."""
    rows: list[list[InlineKeyboardButton]] = []
    web = _webapp_button()
    if web is not None:
        rows.append([web])
    rows.extend(
        [
            [
                InlineKeyboardButton(text="🏪 Бизнесы", callback_data=CB_BUSINESSES),
                InlineKeyboardButton(text="🤝 Сотрудники", callback_data=CB_EMPLOYEES),
            ],
            [
                InlineKeyboardButton(text="📋 Задания", callback_data=CB_TASKS),
                InlineKeyboardButton(text="🏆 Достижения", callback_data=CB_ACHIEVEMENTS),
            ],
            [
                InlineKeyboardButton(text="📊 Рейтинг", callback_data=CB_LEADERBOARD),
                InlineKeyboardButton(text="👤 Профиль", callback_data=CB_PROFILE),
            ],
        ]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _back_home_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🏠 В меню", callback_data=CB_HOME)]
        ]
    )


# --- Утилиты ----------------------------------------------------------------


def _name_of(user) -> str:
    """Имя пользователя из объекта aiogram User."""
    first = user.first_name or ""
    last = user.last_name or ""
    return (first + " " + last).strip() or (user.username or "Игрок")


def _fmt(n: int) -> str:
    """Форматирование чисел с разделителями тысяч."""
    return f"{n:,}".replace(",", " ")


def _ensure_registered(user_id: int, name: str):
    """Гарантирует наличие игрока в БД."""
    db = get_db()
    game_logic.ensure_player(db, user_id, name)


def _extract_ref(start_args: str) -> int | None:
    """Из /start ref_123 извлекает 123 или None."""
    if not start_args:
        return None
    if start_args.startswith("ref_"):
        try:
            return int(start_args.split("_", 1)[1])
        except ValueError:
            return None
    return None


class BanMiddleware(BaseMiddleware):
    """
    Блокирует любые действия забаненных игроков.

    Если игрок забанен (в т.ч. через админ-панель), бот не обрабатывает его
    сообщения и нажатия кнопок, а отвечает коротким предупреждением.
    """

    async def __call__(self, handler, event: TelegramObject, data: dict):
        user = data.get("event_from_user")
        if user is not None:
            try:
                banned = admin_logic.is_banned(get_db(), user.id)
            except Exception:
                banned = False
            if banned:
                try:
                    if isinstance(event, CallbackQuery):
                        await event.answer("⛔ Вы забанены в игре", show_alert=True)
                    elif isinstance(event, Message):
                        await event.answer("⛔ Вы забанены в игре. Доступ закрыт.")
                except Exception:
                    pass
                return None  # дальше обработчики не вызываются
        return await handler(event, data)


# --- Главное меню -----------------------------------------------------------


async def _profile_text(user_id: int, name: str) -> str:
    """Текст главного меню / профиля со сводкой."""
    db = get_db()
    me = game_logic.get_me(db, user_id, name)
    owned = sum(1 for b in me["businesses"] if b["owned"])
    hired = sum(1 for e in me["employees"] if e["count"] > 0)
    return (
        f"🏪 <b>Tiny Business</b>\n\n"
        f"👤 {html.bold(name)}\n"
        f"🪙 Баланс: <b>{_fmt(me['balance'])}</b>\n"
        f"💵 Доход: <b>+{_fmt(me['money_per_min'])}/мин</b>\n"
        f"🏢 Предприятий: {owned}\n"
        f"🤝 Сотрудников: {hired}\n"
        f"💰 Всего заработано: {_fmt(me['total_earned'])}"
    )


async def cmd_start(message: Message):
    """Начало: регистрация + реферал + главное меню."""
    user_id = message.from_user.id
    name = _name_of(message.from_user)

    db = get_db()
    is_new = game_logic.ensure_player(db, user_id, name)

    # Обработка реферала по deep link
    args = message.get_args()
    ref_id = _extract_ref(args)
    if ref_id is not None and ref_id != user_id:
        game_logic.process_referral(db, user_id, ref_id)

    text = await _profile_text(user_id, name)
    if is_new:
        text = "🎉 Добро пожаловать в Tiny Business!\n\n" + text

    await message.answer(text, reply_markup=_home_kb(), parse_mode=ParseMode.HTML)


async def cmd_help(message: Message):
    await message.answer(
        "🆘 <b>Справка Tiny Business</b>\n\n"
        "🏪 Открывай предприятия и улучшай их кнопкой «Бизнесы».\n"
        "💰 Доход копится даже когда ты офлайн (до 8 часов).\n"
        "🤝 Нанимай сотрудников в разделе «Сотрудники».\n"
        "📋 Выполняй задания — получай монеты.\n"
        "👥 Приглашай друзей по ссылке из «Профиль».\n\n"
        "Команды:\n"
        "/start — главное меню\n"
        "/profile — мой прогресс\n"
        "/top — рейтинг\n"
        "/help — справка",
        parse_mode=ParseMode.HTML,
    )


async def cmd_profile(message: Message):
    """Команда /profile — то же, что главное меню."""
    user_id = message.from_user.id
    name = _name_of(message.from_user)
    text = await _profile_text(user_id, name)
    await message.answer(text, reply_markup=_home_kb(), parse_mode=ParseMode.HTML)


async def cmd_top(message: Message):
    """Команда /top — рейтинг."""
    user_id = message.from_user.id
    db = get_db()
    board = game_logic.get_leaderboard(db, user_id)
    lines = ["🏆 <b>Рейтинг капитала</b>\n"]
    medals = ["🥇", "🥈", "🥉"]
    for row in board["rows"]:
        icon = medals[row["position"] - 1] if row["position"] <= 3 else f"{row['position']}."
        lines.append(f"{icon} {html.bold(row['name'])} — {_fmt(row['balance'])} 🪙")
    if board["player"]:
        lines.append(
            f"\n… твоя позиция: <b>{board['player']['position']}</b> "
            f"({_fmt(board['player']['balance'])} 🪙)"
        )
    await message.answer("\n".join(lines), reply_markup=_back_home_kb(), parse_mode=ParseMode.HTML)


# --- Обработчики меню (callback) -------------------------------------------


async def cb_home(callback: CallbackQuery):
    await callback.answer()
    user_id = callback.from_user.id
    name = _name_of(callback.from_user)
    text = await _profile_text(user_id, name)
    await callback.message.edit_text(text, reply_markup=_home_kb(), parse_mode=ParseMode.HTML)


async def cb_businesses(callback: CallbackQuery):
    await callback.answer()
    user_id = callback.from_user.id
    name = _name_of(callback.from_user)
    db = get_db()
    me = game_logic.get_me(db, user_id, name)

    lines = ["🏪 <b>Бизнесы</b>\n"]
    kb = []
    for b in me["businesses"]:
        status = f"Ур.{b['level']} · +{_fmt(b['income'])}/мин" if b["owned"] else f"Открыть · {_fmt(b['next_cost'])} 🪙"
        name_line = f"{b['emoji']} {b['name']}"
        label = f"{name_line} — {status}"
        if b["owned"]:
            label = f"⬆️ {name_line} → ур.{b['level'] + 1} ({_fmt(b['next_cost'])} 🪙)"
        kb.append([InlineKeyboardButton(text=label, callback_data=f"{BUY_BIZ}:{b['business_id']}")])
    kb.append([InlineKeyboardButton(text="🏠 В меню", callback_data=CB_HOME)])

    await callback.message.edit_text(
        "\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=kb),
        parse_mode=ParseMode.HTML,
    )


async def cb_employees(callback: CallbackQuery):
    await callback.answer()
    user_id = callback.from_user.id
    name = _name_of(callback.from_user)
    db = get_db()
    me = game_logic.get_me(db, user_id, name)

    lines = ["🤝 <b>Сотрудники</b>\n"]
    kb = []
    for e in me["employees"]:
        if e["count"] > 0:
            label = f"✅ {e['emoji']} {e['name']} — нанят"
            # нажатие неактивно, но мы показываем
            kb.append([InlineKeyboardButton(text=label, callback_data="noop")])
        else:
            label = f"{e['emoji']} {e['name']} ({_fmt(e['cost'])} 🪙) · {e['bonus_description']}"
            kb.append([InlineKeyboardButton(text=label, callback_data=f"{BUY_EMP}:{e['employee_id']}")])
    kb.append([InlineKeyboardButton(text="🏠 В меню", callback_data=CB_HOME)])

    await callback.message.edit_text(
        "\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=kb),
        parse_mode=ParseMode.HTML,
    )


async def cb_tasks(callback: CallbackQuery):
    await callback.answer()
    user_id = callback.from_user.id
    db = get_db()
    # Обновляем прогресс заданий и получаем их
    game_logic.update_task_progress(db, user_id, "view")
    tasks = game_logic.get_tasks(db, user_id)

    lines = ["📋 <b>Задания на сегодня</b>\n"]
    kb = []
    for t in tasks:
        if t["claimed"]:
            status = "✅ получено"
        elif t["done"]:
            status = f"🎁 +{t['reward']} 🪙 — забрать!"
            kb.append([InlineKeyboardButton(text=f"🎁 Забрать ({t['reward']} 🪙)", callback_data=f"{CLAIM_TASK}:{t['key']}")])
        else:
            status = f"{t['progress']}/{t['target']}"
        lines.append(f"{t['emoji']} {t['title']} — {status}")
    kb.append([InlineKeyboardButton(text="🏠 В меню", callback_data=CB_HOME)])

    await callback.message.edit_text(
        "\n".join(lines), reply_markup=InlineKeyboardMarkup(inline_keyboard=kb),
        parse_mode=ParseMode.HTML,
    )


async def cb_achievements(callback: CallbackQuery):
    await callback.answer()
    user_id = callback.from_user.id
    db = get_db()
    game_logic.update_achievements(db, user_id)
    ach = game_logic.get_achievements(db, user_id)

    lines = ["🏆 <b>Достижения</b>\n"]
    for a in ach:
        mark = "✅" if a["claimed"] else ("⏳" if a["done"] else "🔒")
        lines.append(f"{mark} {a['emoji']} {a['title']} (+{_fmt(a['reward'])} 🪙)")
    lines.append("")
    lines.append("Обычно достижения открываются автоматически.")

    await callback.message.edit_text(
        "\n".join(lines), reply_markup=_back_home_kb(), parse_mode=ParseMode.HTML,
    )


async def cb_leaderboard(callback: CallbackQuery):
    await callback.answer()
    user_id = callback.from_user.id
    name = _name_of(callback.from_user)
    db = get_db()
    _ensure_registered(user_id, name)
    board = game_logic.get_leaderboard(db, user_id)

    lines = ["🏆 <b>Рейтинг капитала</b>\n"]
    medals = ["🥇", "🥈", "🥉"]
    for row in board["rows"]:
        icon = medals[row["position"] - 1] if row["position"] <= 3 else f"{row['position']}."
        lines.append(f"{icon} {html.bold(row['name'])} — {_fmt(row['balance'])} 🪙")
    if board["player"]:
        lines.append(
            f"\n… твоя позиция: <b>{board['player']['position']}</b> "
            f"({_fmt(board['player']['balance'])} 🪙)"
        )

    await callback.message.edit_text(
        "\n".join(lines), reply_markup=_back_home_kb(), parse_mode=ParseMode.HTML,
    )


async def cb_profile(callback: CallbackQuery):
    await callback.answer()
    user_id = callback.from_user.id
    name = _name_of(callback.from_user)
    text = await _profile_text(user_id, name)

    # Реферальная ссылка
    db = get_db()
    ref = game_logic.get_referral_info(db, user_id)
    text += (
        f"\n\n👥 <b>Пригласи друга</b>\n"
        f"{ref['referral_link']}\n"
        f"Приглашено: {ref['invited_count']} · +{ref['reward']} 🪙 за друга"
    )

    kb = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="🏠 В меню", callback_data=CB_HOME)]
        ]
    )
    await callback.message.edit_text(text, reply_markup=kb, parse_mode=ParseMode.HTML)


# --- Действия: покупки / задания -------------------------------------------


async def cb_buy_business(callback: CallbackQuery):
    user_id = callback.from_user.id
    name = _name_of(callback.from_user)
    biz_id = callback.data.split(":", 1)[1]
    db = get_db()

    res = game_logic.buy_business(db, user_id, biz_id)
    if res["success"]:
        game_logic.update_task_progress(db, user_id, "business")
        game_logic.update_achievements(db, user_id)
        me = game_logic.get_me(db, user_id, name)
        await callback.answer(f"✅ {res['message']} Баланс: {_fmt(me['balance'])} 🪙", show_alert=False)
    else:
        await callback.answer(res["message"], show_alert=True)
        return

    # Перерисовываем экран бизнесов
    await cb_businesses(callback)


async def cb_buy_employee(callback: CallbackQuery):
    user_id = callback.from_user.id
    name = _name_of(callback.from_user)
    emp_id = callback.data.split(":", 1)[1]
    db = get_db()

    res = game_logic.buy_employee(db, user_id, emp_id)
    if res["success"]:
        game_logic.update_task_progress(db, user_id, "employee")
        game_logic.update_achievements(db, user_id)
        me = game_logic.get_me(db, user_id, name)
        await callback.answer(f"✅ {res['message']} Баланс: {_fmt(me['balance'])} 🪙")
    else:
        await callback.answer(res["message"], show_alert=True)
        return

    await cb_employees(callback)


async def cb_claim_task(callback: CallbackQuery):
    user_id = callback.from_user.id
    name = _name_of(callback.from_user)
    task_key = callback.data.split(":", 1)[1]
    db = get_db()

    res = game_logic.claim_task(db, user_id, task_key)
    if res["success"]:
        me = game_logic.get_me(db, user_id, name)
        await callback.answer(f"✅ {res['message']} Баланс: {_fmt(me['balance'])} 🪙")
    else:
        await callback.answer(res["message"], show_alert=True)

    await cb_tasks(callback)


async def cb_noop(callback: CallbackQuery):
    await callback.answer()


async def cmd_admin(message: Message):
    """Краткая сводка для админа (полная панель — в Mini App)."""
    user_id = message.from_user.id
    if not admin_logic.is_admin(user_id):
        await message.answer("⛔ Команда только для администраторов.")
        return
    st = admin_logic.stats(get_db())
    await message.answer(
        "🛠 <b>Администрирование</b>\n\n"
        f"👥 Игроков: <b>{st['users']}</b>\n"
        f"🚫 Забанено: <b>{st['banned']}</b>\n"
        f"🪙 Монет в игре: <b>{st['total_balance']}</b>\n"
        f"🏢 Предприятий открыто: <b>{st['businesses']}</b>\n"
        f"🛡 Админов: {st['admins']}\n\n"
        "Полная панель (выдача ресурсов, баны, заявки, рассылка) — "
        "в Mini App, кнопка «Играть» → раздел 🛠 «Админ».",
        parse_mode=ParseMode.HTML,
    )


async def _broadcast_worker(bot: Bot) -> None:
    """
    Фоновый воркер рассылки.

    Раз в несколько секунд берёт из очереди следующую рассылку и отправляет
    её всем игрокам. Устойчив к перезапускам: «кому уже отправили» хранится
    в broadcast_recipients, поэтому дублей не будет даже после падения.
    Забаненные игроки пропускаются.
    """
    logger.info("Broadcast worker started")
    while True:
        try:
            db = get_db()
            bc = broadcast_logic.get_pending_broadcast(db)
            if bc is not None:
                await _process_broadcast(bot, bc)
        except Exception as e:  # pragma: no cover
            logger.warning("Broadcast worker error: %s", e)
        await asyncio.sleep(3)


async def _process_broadcast(bot: Bot, bc: dict) -> None:
    """Обрабатывает одну рассылку из очереди."""
    db = get_db()
    bcid = bc["id"]
    broadcast_logic.mark_broadcast_running(db, bcid)

    failed = 0
    for uid in broadcast_logic.broadcast_targets(db, bcid):
        if broadcast_logic.already_sent(db, bcid, uid):
            continue
        if admin_logic.is_banned(db, uid):
            # баны тоже помечаем как «обработано», чтобы не крутить их вечно
            broadcast_logic.add_broadcast_recipient(db, bcid, uid)
            continue
        try:
            await bot.send_message(uid, bc["text"])
            broadcast_logic.add_broadcast_recipient(db, bcid, uid)
        except Exception:
            failed += 1
            # Возможные причины: юзер заблокировал бота, не начинал диалог и т.п.
            broadcast_logic.add_broadcast_recipient(db, bcid, uid)
        await asyncio.sleep(broadcast_logic.rate_limited())

    broadcast_logic.finish_broadcast(db, bcid, failed)
    logger.info("Broadcast #%s done (failed=%s)", bcid, failed)


# --- Запуск ----------------------------------------------------------------


async def main():
    """Точка входа бота: long-polling."""
    if not config.BOT_TOKEN:
        logger.error("BOT_TOKEN не задан в .env. Бот не запущен.")
        return

    bot = Bot(
        token=config.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher()

    # Блокировка забаненных игроков (до всех обработчиков)
    ban_mw = BanMiddleware()
    dp.message.middleware(ban_mw)
    dp.callback_query.middleware(ban_mw)

    # Фоновый воркер рассылки (запускается после старта polling)
    dp.startup.register(
        lambda _bot: asyncio.create_task(_broadcast_worker(_bot))
    )

    # Команды
    dp.message.register(cmd_start, CommandStart())
    dp.message.register(cmd_help, Command(commands=["help"]))
    dp.message.register(cmd_profile, Command(commands=["profile"]))
    dp.message.register(cmd_top, Command(commands=["top"]))
    dp.message.register(cmd_admin, Command(commands=["admin"]))

    # Меню
    dp.callback_query.register(cb_home, F.data == CB_HOME)
    dp.callback_query.register(cb_businesses, F.data == CB_BUSINESSES)
    dp.callback_query.register(cb_employees, F.data == CB_EMPLOYEES)
    dp.callback_query.register(cb_tasks, F.data == CB_TASKS)
    dp.callback_query.register(cb_achievements, F.data == CB_ACHIEVEMENTS)
    dp.callback_query.register(cb_leaderboard, F.data == CB_LEADERBOARD)
    dp.callback_query.register(cb_profile, F.data == CB_PROFILE)

    # Действия
    dp.callback_query.register(cb_buy_business, F.data.startswith(f"{BUY_BIZ}:"))
    dp.callback_query.register(cb_buy_employee, F.data.startswith(f"{BUY_EMP}:"))
    dp.callback_query.register(cb_claim_task, F.data.startswith(f"{CLAIM_TASK}:"))
    dp.callback_query.register(cb_noop, F.data == "noop")

    logger.info("Starting Tiny Business bot…")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())